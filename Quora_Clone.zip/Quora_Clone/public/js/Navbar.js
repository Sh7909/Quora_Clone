const home = () => {
    localStorage.setItem("runhomefunction", "true");
  };
  const followingicon = (event) => {
    event.preventDefault();
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    following.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "block";
    Homeiconline.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "none";
  };
  const answericon = () => {
    localStorage.setItem("runAnswerFunction", "true");
  };
  const notificationicon = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    notifications.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "none";
    Homeiconline.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "block";
  };
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded', () => {
    tooltip.className = "tooltip";
    document.body.appendChild(tooltip);
  })


  // Show tooltip
  const tooltip = document.createElement("div");
  function showTooltip(event) {
    const text = event.target.getAttribute("data-tooltip");
    if (text) {
      tooltip.textContent = text;
      tooltip.classList.add("show");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip.style.top = `${event.pageY + tooltipOffset}px`;
  }

  // Hide tooltip
  function hideTooltip() {
    tooltip.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded', () => {
    const tooltip2 = document.createElement("div");
    tooltip2.className = "tooltiptwo";
    document.body.appendChild(tooltip2);
  });

  // Show tooltip
  const tooltip2 = document.createElement("div");
  function showTooltip2(event) {
    const text2 = event.target.getAttribute("data-tooltip");
    if (text2) {
      tooltip2.textContent = text2;
      tooltip2.classList.add("show");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip2(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip2.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip2.style.top = `${event.pageY + tooltipOffset}px`;
  }

  //Hide tooltip
  function hideTooltip2() {
    tooltip2.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded', () => {
    const tooltip3 = document.createElement("div");
    tooltip3.className = "tooltipthree";
    document.body.appendChild(tooltip3);
  });

  // Show tooltip
  const tooltip3 = document.createElement("div");
  function showTooltip3(event) {
    const text3 = event.target.getAttribute("data-tooltip");
    if (text3) {
      tooltip3.textContent = text3;
      tooltip3.classList.add("show");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip3(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip3.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip3.style.top = `${event.pageY + tooltipOffset}px`;
  }

  //Hide tooltip
  function hideTooltip3() {
    tooltip3.classList.remove("show");
  }

  // Create a tooltip element
  document.addEventListener('DOMContentLoaded', () => {
    const tooltip5 = document.createElement("div");
    tooltip5.className = "tooltipfive";
    document.body.appendChild(tooltip5);
  });
  // Show tooltip
  const tooltip5 = document.createElement("div");
  function showTooltip5(event) {
    const text5 = event.target.getAttribute("data-tooltip");
    if (text5) {
      tooltip5.textContent = text5;
      tooltip5.classList.add("show");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip5(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip5.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip5.style.top = `${event.pageY + tooltipOffset}px`;
  }

  //Hide tooltip
  function hideTooltip5() {
    tooltip5.classList.remove("show");
  }
  const tryquora = () => {
    const tryquorasection = document.querySelector(".tryquorasection");
    const maincontainer = document.querySelector(".main_container");
    const styleeffect = document.querySelector(".styleeffect");
    const askquestions = document.querySelector(".ask_questions");
    const postcontainer = document.querySelector(".postcontainer");
    const postsection1 = document.querySelector(".postsection1");
    const postsection2 = document.querySelector(".postsection2");
    const postsection3 = document.querySelector(".postsection3");
    const postsection4 = document.querySelector(".postsection4");
    const Nav = document.querySelector("#Nav");
    tryquorasection.style.display = "block";
    styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
    askquestions.style.position = "sticky";
    postcontainer.style.top = "2rem";
    postsection1.style.filter = "brightness(0.5)";
    postsection2.style.filter = "brightness(0.5)";
    postsection3.style.filter = "brightness(0.5)";
    postsection4.style.filter = "brightness(0.5)";
    askquestions.style.filter = "brightness(0.5)";
    Nav.style.filter = "brightness(0.5)";
    maincontainer.style.filter = "brightness(0.5)";
  };
  const Openlangdivcontainer = () => {
    const languagediv = document.querySelector('.languagediv');
    const currentDisplay = window.getComputedStyle(languagediv).display;
    if (currentDisplay == "none") {
      languagediv.style.display = "block";
    }
    else {
      languagediv.style.display = "none";
    }
  }
  const closelangdiv = () => {
    const languagediv = document.querySelector('.languagediv');
    languagediv.style.display = "none";
  }
  const openemaildialogbox = () => {
    const emailcontainer = document.querySelector('.emailcontainer');
    const currentDisplay = window.getComputedStyle(emailcontainer).display;
    if (currentDisplay == "none") {
      emailcontainer.style.display = "block";
    }
    else {
      emailcontainer.style.display = "none";
    }
  }