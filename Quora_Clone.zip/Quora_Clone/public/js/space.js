const home = () => {
    localStorage.setItem("runhomefunction", "true");
  };
  const followingicon = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    following.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "block";
    Homeiconline.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "none";
  };
  const answericon = () => {
    localStorage.setItem("runAnswerFunction", "true");
  };
  const notificationicon = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    notifications.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "none";
    Homeiconline.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "block";
  };
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
    const tooltip = document.createElement("div");
    tooltip.className = "tooltip";
    document.body.appendChild(tooltip);
  });
  // Show tooltip
  const tooltip = document.createElement("div");
  function showTooltip(event) {
    const text = event.target.getAttribute("data-tooltip");
    if (text) {
      tooltip.textContent = text;
      tooltip.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  // Hide tooltip
  function hideTooltip() {
    tooltip.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
  const tooltip2 = document.createElement("div");
  tooltip2.className = "tooltiptwo";
  document.body.appendChild(tooltip2);
  });
  
  // Show tooltip
  const tooltip2 = document.createElement("div");
  function showTooltip2(event) {
    const text2 = event.target.getAttribute("data-tooltip");
    if (text2) {
      tooltip2.textContent = text2;
      tooltip2.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip2(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip2.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip2.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  //Hide tooltip
  function hideTooltip2() {
    tooltip2.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
  const tooltip3 = document.createElement("div");
  tooltip3.className = "tooltipthree";
  document.body.appendChild(tooltip3);
  });
  // Show tooltip
  const tooltip3 = document.createElement("div");
  function showTooltip3(event) {
    const text3 = event.target.getAttribute("data-tooltip");
    if (text3) {
      tooltip3.textContent = text3;
      tooltip3.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip3(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip3.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip3.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  //Hide tooltip
  function hideTooltip3() {
    tooltip3.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
  const tooltip5 = document.createElement("div");
  tooltip5.className = "tooltipfive";
  document.body.appendChild(tooltip5);
  });
  
  // Show tooltip
  const tooltip5 = document.createElement("div");
  function showTooltip5(event) {
    const text5 = event.target.getAttribute("data-tooltip");
    if (text5) {
      tooltip5.textContent = text5;
      tooltip5.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip5(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip5.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip5.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  //Hide tooltip
  function hideTooltip5() {
    tooltip5.classList.remove("show");
  }
  const tryquora = () => {
    const tryquorasection = document.querySelector(".tryquorasection");
    const spacecontainer=document.querySelector(".spacecontainer");
    const containerfirst=document.querySelector('.containerfirst');
    const Nav = document.querySelector("#Nav");
    tryquorasection.style.display = "block";
    spacecontainer.style.filter="brightness(0.5)";
    Nav.style.filter = "brightness(0.5)";
    containerfirst.style.backgroundColor="gray";
  };
  const Openlangdivcontainer=()=>{
    const languagediv=document.querySelector('.languagediv');
    const currentDisplay=window.getComputedStyle(languagediv).display;
    if(currentDisplay=="none"){
      languagediv.style.display="block";
    }
    else{
      languagediv.style.display="none";
    }
  }
  const closelangdiv=()=>{
    const languagediv=document.querySelector('.languagediv');
    languagediv.style.display="none";
  }
  const openemaildialogbox=()=>{
    const emailcontainer=document.querySelector('.emailcontainer');
    const currentDisplay=window.getComputedStyle(emailcontainer).display;
    if(currentDisplay=="none"){
      emailcontainer.style.display="block";
    }
    else{
      emailcontainer.style.display="none";
    }
  }
  function execute1 (){
    const showq1 = document.querySelector(".showq1");
    const admindashboard = document.querySelector(".admindashboard");
    const containerfirst = document.querySelector(".containerfirst");
    const currentDisplay = window.getComputedStyle(showq1).display;
  
    if (currentDisplay === "none") {
      showq1.style.display = "block";
      admindashboard.style.height = "120%";
      containerfirst.style.height = "180%";
    } else {
      showq1.style.display = "none";
      containerfirst.style.height = "161%";
    }
  };
  
  function execute2 (){
    const showq2 = document.querySelector(".showq2");
    const admindashboard = document.querySelector(".admindashboard");
    const currentDisplay = window.getComputedStyle(showq2).display;
  
    if (currentDisplay == "none") {
      showq2.style.display = "block";
      admindashboard.style.height = "120%";
    } else {
      showq2.style.display = "none";
    }
  };
  function execute3 () {
    const showq3 = document.querySelector(".showq3");
    const admindashboard = document.querySelector(".admindashboard");
    const containerfirst = document.querySelector(".containerfirst");
    const currentDisplay = window.getComputedStyle(showq3).display;
  
    if (currentDisplay == "none") {
      showq3.style.display = "block";
      admindashboard.style.height = "120%";
      containerfirst.style.height = "164%";
    } else {
      showq3.style.display = "none";
    }
  };
  function execute5 () {
    const showq5 = document.querySelector(".showq5");
    const admindashboard = document.querySelector(".admindashboard");
    const containerfirst = document.querySelector(".containerfirst");
    const currentDisplay = window.getComputedStyle(showq5).display;
  
    if (currentDisplay == "none") {
      showq5.style.display = "block";
      admindashboard.style.height = "120%";
      containerfirst.style.height = "164%";
    } else {
      showq5.style.display = "none";
    }
  };
  function execute6() {
    const dialogbox = document.querySelector(".dialogbox");
    const currentDisplay = window.getComputedStyle(dialogbox).display;
    if (currentDisplay == "none") {
      dialogbox.style.display = "block";
    } else {
      dialogbox.style.display = "none";
    }
  };
  const start1 = () => {
    const dbox6 = document.querySelector(".dbox6");
    const dbox7 = document.querySelector(".dbox7");
    const dbox8 = document.querySelector(".dbox8");
    if (dbox6.value == "") {
      dbox7.style.backgroundColor = "rgb(150, 180, 255)";
      dbox8.style.backgroundColor = "rgb(150, 180, 255)";
      dbox7.style.cursor = "not-allowed";
      dbox8.style.cursor = "not-allowed";
    } else {
      dbox7.style.backgroundColor = "rgb(26, 90, 255)";
      dbox8.style.backgroundColor = "rgb(26, 90, 255)";
      dbox7.style.cursor = "pointer";
      dbox8.style.cursor = "pointer";
    }
  };
  const descriptiondialog1 = () => {
    const Nav = document.querySelector("#Nav");
    const spacecontainer = document.querySelector(".spacecontainer");
    const dbox1 = document.querySelector(".dbox1");
    const containerfirst = document.querySelector(".containerfirst");
    Nav.style.filter = "brightness(0.5)";
    spacecontainer.style.filter = "brightness(0.5)";
    dbox1.style.display = "block";
    containerfirst.style.backgroundColor = "rgb(128, 128, 128)";
  };
  const descriptiondialog2 = () => {
    const Nav = document.querySelector("#Nav");
    const spacecontainer = document.querySelector(".spacecontainer");
    const dbox9 = document.querySelector(".dbox9");
    const containerfirst = document.querySelector(".containerfirst");
    Nav.style.filter = "brightness(0.5)";
    spacecontainer.style.filter = "brightness(0.5)";
    dbox9.style.display = "block";
    containerfirst.style.backgroundColor = "rgb(128, 128, 128)";
    containerfirst.style.height = "164%";
  };
  function closecircle1() {
    const dbox1 = document.querySelector(".dbox1");
    const Nav = document.querySelector("#Nav");
    const spacecontainer = document.querySelector(".spacecontainer");
    const containerfirst = document.querySelector(".containerfirst");
    dbox1.style.display = "none";
    Nav.style.filter = "";
    spacecontainer.style.filter = "";
    containerfirst.style.backgroundColor = "";
  };
  const closecircle2 = () => {
    const sharespacenow = document.querySelector("#sharespacenow");
    closecircle1();
    sharespacenow.style.display = "none";
  };
  const save1 = () => {
    const addtext = document.querySelector(".addtext");
    const dbox6 = document.querySelector(".dbox6");
    const seconddiv = document.querySelector(".seconddiv");
    const showq1 = document.querySelector(".showq1");
    const secondline = document.querySelector(".secondline");
    closecircle1();
    addtext.innerHTML = dbox6.value;
    seconddiv.style.display = "none";
    showq1.style.display = "none";
    secondline.style.display = "none";
  };
  const spacecolor = () => {
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    const currentDisplay = window.getComputedStyle(colorpickerdiv).display;
  
    if (currentDisplay == "none") {
      colorpickerdiv.style.display = "block";
      colorpickerdiv.style.display = "flex";
    } else {
      colorpickerdiv.style.display = "none";
    }
  };
  function save2() {
    const dbox9 = document.querySelector(".dbox9");
    const spacecontainer = document.querySelector(".spacecontainer");
    const spaceColor = document.querySelector(".spaceColor");
    const appendedimg = document.querySelector(".appendedimg");
    const previewImage1 = document.querySelector("#previewImage1");
    const previewImage2 = document.querySelector("#previewImage2");
    const firstimg = document.querySelector("#firstimg");
    const shownimg = document.querySelector("#shownimg");
    const thirdline = document.querySelector(".thirdline");
    const value = spaceColor.style.backgroundColor;
  
    closecircle1();
    dbox9.style.display = "none";
    thirdline.style.display = "none";
    spacecontainer.style.backgroundImage = `linear-gradient(${value},${value})`;
    if (previewImage1.src == "") {
      firstimg.style.display = "block";
      appendedimg.style.display = "none";
    } else {
      firstimg.style.display = "none";
      appendedimg.appendChild(previewImage1);
    }
  
    if (previewImage2.src == "") {
      shownimg.style.backgroundImage = `url(https://qsf.cf2.quoracdn.net/-4-ans_frontend_assets.images.tribes.defaults.space_banner_green.png-26-f0b46f18277322da.png)`;
    } else {
      shownimg.style.backgroundImage = `url(${previewImage2.src})`;
    }
    document.querySelector("#question2").style.display = "none";
    document.querySelector(".showq2").style.display = "none";
    document.querySelector(".secondline").style.display = "none";
  };
  const firstcolor = () => {
    const color1 = document.querySelector("#color1");
    const spaceColor = document.querySelector(".spaceColor");
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    spaceColor.style.backgroundColor = color1.value;
    colorpickerdiv.style.display = "none";
  };
  const secondcolor = () => {
    const color2 = document.querySelector("#color2");
    const spaceColor = document.querySelector(".spaceColor");
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    spaceColor.style.backgroundColor = color2.value;
    colorpickerdiv.style.display = "none";
  };
  const thirdcolor = () => {
    const color3 = document.querySelector("#color3");
    const spaceColor = document.querySelector(".spaceColor");
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    spaceColor.style.backgroundColor = color3.value;
    colorpickerdiv.style.display = "none";
  };
  const fourthcolor = () => {
    const color4 = document.querySelector("#color4");
    const spaceColor = document.querySelector(".spaceColor");
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    spaceColor.style.backgroundColor = color4.value;
    colorpickerdiv.style.display = "none";
  };
  const fifthcolor = () => {
    const color5 = document.querySelector("#color5");
    const spaceColor = document.querySelector(".spaceColor");
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    spaceColor.style.backgroundColor = color5.value;
    colorpickerdiv.style.display = "none";
  };
  const sixthcolor = () => {
    const color6 = document.querySelector("#color6");
    const spaceColor = document.querySelector(".spaceColor");
    const colorpickerdiv = document.querySelector(".colorpickerdiv");
    spaceColor.style.backgroundColor = color6.value;
    colorpickerdiv.style.display = "none";
  };
  const clickicon1 = () => {
    document.getElementById("editbtn").addEventListener("click", function () {
      document.getElementById("fileInput1").click();
    });
  };
  function previewFile1() {
    const file = document.getElementById("fileInput1").files[0];
    const reader = new FileReader();
  
    reader.onloadend = function () {
      const image1 = document.querySelector("#image1");
      image1.style.display = "none";
      document.getElementById("previewImage1").style.display = "block";
      document.getElementById("previewImage1").src = reader.result;
    };
  
    if (file) {
      reader.readAsDataURL(file);
    }
  }
  document.addEventListener("DOMContentLoaded", function () {
    // Attach event listener when DOM is fully loaded
    document.getElementById("editbtn2").addEventListener("click", function () {
      document.getElementById("fileInput2").click();
    });
  
    document.getElementById("fileInput2").addEventListener("change", function () {
      previewFile2();
    });
  });
  
  function previewFile2() {
    const file = document.getElementById("fileInput2").files[0];
    const reader = new FileReader();
  
    reader.onloadend = function () {
      const image2 = document.getElementById("image2");
      const previewImage2 = document.getElementById("previewImage2");
      const editicon2 = document.getElementById("editicon2");
  
      if (image2) image2.style.display = "none"; // Hide default image
      previewImage2.style.display = "block"; // Show uploaded image
      previewImage2.src = reader.result;
      editicon2.style.left = "6rem";
    };
  
    if (file) {
      reader.readAsDataURL(file);
    }
  }
  const createpost1 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const Nav = document.querySelector("#Nav");
    const spacecontainer = document.querySelector(".spacecontainer");
    const containerfirst = document.querySelector(".containerfirst");
    questiondialogbox.style.display = "block";
    Nav.style.filter = "brightness(0.5)";
    spacecontainer.style.filter = "brightness(0.5)";
    containerfirst.style.backgroundColor = "rgb(128, 128, 128)";
    containerfirst.style.height = "164%";
  };
  const hoveroutcolor = () => {
    const line = document.querySelector(".line");
    line.style.border = "";
  };
  const startnow = () => {
    const questionstart = document.querySelector("#questionstart");
    const after = document.querySelector("#after");
    questionstart.style.display = "none";
    after.style.display = "block";
  };
  const exec = () => {
    const textarea = document.querySelector("#after");
    const line = document.querySelector(".line");
    const addquestion = document.querySelector("#addquestion");
  
    // Get the scroll height (amount of overflow) of the textarea
    const textHeight = textarea.scrollHeight;
  
    // Adjust the position of the <hr> based on the textarea's height
    // Add some spacing
  
    if (textarea.value.trim() === "") {
      addquestion.style.opacity = 0.4;
      line.style.top = "10%";
    } else {
      addquestion.style.opacity = 1;
      line.style.top = `${textHeight + 0.2}px`;
    }
  };
  const createpost = () => {
    const postdiv = document.querySelector("#postdiv");
    const Enable = document.querySelector("#Enable");
    postdiv.style.display = "none";
    Enable.style.display = "block";
  };
  const exec2 = () => {
    const textarea = document.querySelector("#Enable");
    const postbtn = document.querySelector("#postbtn");
  
    if (textarea.value.trim() === "") {
      postbtn.style.opacity = 0.4;
      postbtn.style.cursor = "default";
    } else {
      postbtn.style.opacity = 1;
      postbtn.style.cursor = "pointer";
    }
  };
  const senddata = () => {
    const getdata = document.querySelector("#Enable").value;
    const imageElements = document.querySelectorAll(".imagesection img");
    const question3 = document.querySelector("#question3");
    const showq3 = document.querySelector(".showq3");
  
    const formData = new FormData();
    formData.append("getdata", getdata);
    question3.style.display = "none";
    showq3.style.display = "none";
  
    let imagePromises = [];
  
    imageElements.forEach((imageElement, index) => {
      imagePromises.push(
        fetch(imageElement.src)
          .then((response) => response.blob())
          .then((blob) => {
            const file = new File([blob], `uploaded_image_${index}.jpg`, {
              type: blob.type,
            });
            formData.append("images", file);
          })
      );
    });
  
    Promise.all(imagePromises)
      .then(() => {
        return fetch("/postdata", {
          method: "POST",
          body: formData,
        });
      })
      .then((response) => {
        if (response.redirected) {
          window.location.href = response.url;
        }
      })
      .catch((err) => console.error("Error:", err));
    document.querySelector(".fourthline").style.display = "none";
    document.querySelector(".questiondialogbox").style.display = "none";
    closecircle1();
  };
  const postdiv = () => {
    const box7 = document.querySelector(".box7");
    const box9 = document.querySelector(".box9");
    const box10 = document.querySelector(".box10");
    const createpost = document.querySelector(".createpost");
    const text3 = document.querySelector(".text3");
    createpost.style.display = "block";
    box9.style.opacity = 0;
    box10.style.opacity = 1;
    text3.style.display = "block";
    text3.style.display = "flex";
    box7.onmouseover = () => {
      box7.style.backgroundColor = "white";
    };
    box7.onmouseout = () => {
      box7.style.backgroundColor = "white";
    };
  };
  const inputimg = () => {
    const fileInput = document.querySelector("#fileInput");
    const imagesection = document.querySelector(".imagesection");
  
    fileInput.click();
  
    fileInput.addEventListener("change", function (event) {
      const file = event.target.files[0]; // Get the selected file
  
      if (file) {
        const reader = new FileReader();
  
        reader.onload = function (e) {
          const img = document.createElement("img");
          img.src = e.target.result; // Base64 image URL
          img.style.maxWidth = "20%"; // Ensure the image fits
          document.querySelector(".imagesection").appendChild(img); // Insert image
          imagesection.style.display = "block";
        };
        reader.readAsDataURL(file); // Convert image to Base64
      }
      fileInput.value = "";
    });
  };
  const showstyles = () => {
    const shownow = document.querySelector(".shownow");
    const photosvg = document.querySelector("#photosvg");
    const fontstylessvg = document.querySelector("#fontstylessvg");
    shownow.style.display = "block";
    shownow.style.display = "flex";
    photosvg.style.display = "none";
    fontstylessvg.style.display = "none";
  };
  const togglefnc = () => {
    const dropdowntogglebtn = document.querySelector(".dropdowntogglebtn");
    const shownow = document.querySelector(".shownow");
    const photosvg = document.querySelector("#photosvg");
    const fontstylessvg = document.querySelector("#fontstylessvg");
    if (dropdowntogglebtn.style.display == "none") {
      shownow.style.display = "block";
      photosvg.style.display = "none";
      fontstylessvg.style.display = "none";
    } else {
      shownow.style.display = "none";
      photosvg.style.display = "block";
      fontstylessvg.style.display = "block";
    }
  };
  const bold = () => {
    const Enable = document.querySelector("#Enable");
    Enable.addEventListener("focus", () => {
      Enable.style.fontWeight = "bold";
    });
  };
  const italic = () => {
    const Enable = document.querySelector("#Enable");
    Enable.addEventListener("focus", () => {
      Enable.style.fontStyle = "italic";
    });
  };
  
  const invertedcomma = () => {
    const Enable = document.querySelector("#Enable");
    if (Enable) {
      Enable.value += `""`;
    }
  };
  
  const attherate = () => {
    const Enable = document.querySelector("#Enable");
  
    if (Enable) {
      Enable.value = Enable.value.trim(); // Remove extra spaces
      Enable.value += "@";
  
      // Delay and remove {} if they appear
      setTimeout(() => {
        Enable.value = Enable.value.replace(/\{\}/g, "");
      }, 1);
    }
  };
  
  const curlybraces = () => {
    const Enable = document.querySelector("#Enable");
  
    if (Enable) {
      Enable.value = Enable.value.trim();
      Enable.value += "{}";
    }
  };
  const share = () => {
    const sharespacenow = document.querySelector("#sharespacenow");
    const Nav = document.querySelector("#Nav");
    const spacecontainer = document.querySelector(".spacecontainer");
    const containerfirst = document.querySelector(".containerfirst");
    sharespacenow.style.display = "block";
    Nav.style.filter = "brightness(0.5)";
    spacecontainer.style.filter = "brightness(0.5)";
    containerfirst.style.backgroundColor = "rgb(128, 128, 128)";
    containerfirst.style.height = "164%";
  };
  function save3()  {
    const sharespacenow = document.querySelector("#sharespacenow");
    const question4 = document.querySelector("#question4");
    const showq5 = document.querySelector(".showq5");
    sharespacenow.style.display = "none";
    question4.style.display = "none";
    showq5.style.display = "none";
    closecircle1();
  };
  const close1 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    questiondialogbox.style.display = "none";
    closecircle1();
  };
  const closetryquora=()=>{
    const tryquorasection = document.querySelector(".tryquorasection");
    const spacecontainer=document.querySelector(".spacecontainer");
    const containerfirst=document.querySelector('.containerfirst');
    const Nav=document.querySelector('#Nav');
    Nav.style.filter="";
    tryquorasection.style.display = "none";
    spacecontainer.style.filter="";
    Nav.style.filter = "";
    containerfirst.style.backgroundColor="";
  }
  const opendialog = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const spacecontainer=document.querySelector(".spacecontainer");
    const containerfirst=document.querySelector('.containerfirst');
    const Nav = document.querySelector("#Nav");
    questiondialogbox.style.display = "block";
    Nav.style.filter = "brightness(0.5)";
    spacecontainer.style.filter="brightness(0.5)";
    containerfirst.style.backgroundColor="gray";
  };
  const monthlypriceshow=()=>{
    const pricedetails=document.querySelector(".pricedetails");
    const tryquora6=document.querySelector(".tryquora6");
    const tryquora7=document.querySelector(".tryquora7");
    const yearlytxt=document.querySelector(".yearlytxt");
    const pricediv1=document.querySelector(".pricediv1");
    pricedetails.innerText="$6.99/mo";
    tryquora6.style.border="1px solid gainsboro";
    tryquora6.style.backgroundColor="white";
    yearlytxt.style.color="black";
    pricediv1.style.color="black";
    tryquora7.style.border="1px solid rgb(46, 105, 255)";
    tryquora7.style.backgroundColor="rgb(247,247,247)";
  }
  const yearlypriceshow=()=>{
    const pricedetails=document.querySelector(".pricedetails");
    const tryquora6=document.querySelector(".tryquora6");
    const tryquora7=document.querySelector(".tryquora7");
    const yearlytxt=document.querySelector(".yearlytxt");
    const pricediv1=document.querySelector(".pricediv1");
    const monthlytxt=document.querySelector(".monthlytxt");
    const pricediv2=document.querySelector(".pricediv2");
  
    pricedetails.innerText="$47.88/yr";
    tryquora7.style.border="1px solid gainsboro";
    tryquora7.style.backgroundColor="white";
    yearlytxt.style.color="rgb(46, 105, 255)";
    pricediv1.style.color="rgb(46, 105, 255)";
    tryquora6.style.border="1px solid rgb(46, 105, 255)";
    tryquora6.style.backgroundColor="rgb(247,247,247)"; 
    monthlytxt.style.color="black";
    pricediv2.style.color="black";
  }