const first = () => {
const CreateBtn1 = document.querySelector("#CreateBtn1");
const Primary1 = document.querySelector("#Primary1");
CreateBtn1.style.backgroundColor = "#1a5aff";
Primary1.style.backgroundColor = "#1a5aff";
CreateBtn1.onmouseover = () => {
CreateBtn1.style.backgroundColor = "#1a5aff";
};
CreateBtn1.onmouseout = () => {
CreateBtn1.style.backgroundColor = "#1a5aff";
};
Primary1.onmouseover = () => {
Primary1.style.backgroundColor = "#1a5aff";
};
Primary1.onmouseout = () => {
Primary1.style.backgroundColor = "#1a5aff";
};
};

const first1 = () => {
const createbtn1 = document.querySelector("#createbtn1");
const primary1 = document.querySelector("#primary1");
createbtn1.style.backgroundColor = "#1a5aff";
primary1.style.backgroundColor = "#1a5aff";
createbtn1.onmouseover = () => {
createbtn1.style.backgroundColor = "#1a5aff";
};
createbtn1.onmouseout = () => {
createbtn1.style.backgroundColor = "#1a5aff";
};
primary1.onmouseover = () => {
primary1.style.backgroundColor = "#1a5aff";
};
primary1.onmouseout = () => {
primary1.style.backgroundColor = "#1a5aff";
};
};

const first2 = () => {
const createbtn2 = document.querySelector("#createbtn2");
const primary2 = document.querySelector("#primary2");
createbtn2.style.backgroundColor = "#1a5aff";
primary2.style.backgroundColor = "#1a5aff";
createbtn2.onmouseover = () => {
createbtn2.style.backgroundColor = "#1a5aff";
};
createbtn2.onmouseout = () => {
createbtn2.style.backgroundColor = "#1a5aff";
};
primary2.onmouseover = () => {
primary2.style.backgroundColor = "#1a5aff";
};
primary2.onmouseout = () => {
primary2.style.backgroundColor = "#1a5aff";
};
};

const first3 = () => {
const createbtn2 = document.querySelector("#createbtn2");
const primary2 = document.querySelector("#primary2");
createbtn2.style.backgroundColor = "#1a5aff";
primary2.style.backgroundColor = "#1a5aff";
createbtn2.onmouseover = () => {
createbtn2.style.backgroundColor = "#1a5aff";
};
createbtn2.onmouseout = () => {
createbtn2.style.backgroundColor = "#1a5aff";
};
primary2.onmouseover = () => {
primary2.style.backgroundColor = "#1a5aff";
};
primary2.onmouseout = () => {
primary2.style.backgroundColor = "#1a5aff";
};
};

const first4 = () => {
const createbtn3 = document.querySelector("#createbtn3");
const primary3 = document.querySelector("#primary3");
createbtn3.style.backgroundColor = "#1a5aff";
primary3.style.backgroundColor = "#1a5aff";
createbtn3.onmouseover = () => {
createbtn3.style.backgroundColor = "#1a5aff";
};
createbtn3.onmouseout = () => {
createbtn3.style.backgroundColor = "#1a5aff";
};
primary3.onmouseover = () => {
primary3.style.backgroundColor = "#1a5aff";
};
primary3.onmouseout = () => {
primary3.style.backgroundColor = "#1a5aff";
};
};

const first5 = () => {
const createbtn4 = document.querySelector("#createbtn4");
const primary4 = document.querySelector("#primary4");
createbtn4.style.backgroundColor = "#1a5aff";
primary4.style.backgroundColor = "#1a5aff";
createbtn4.onmouseover = () => {
createbtn4.style.backgroundColor = "#1a5aff";
};
createbtn4.onmouseout = () => {
createbtn4.style.backgroundColor = "#1a5aff";
};
primary4.onmouseover = () => {
primary4.style.backgroundColor = "#1a5aff";
};
primary4.onmouseout = () => {
primary4.style.backgroundColor = "#1a5aff";
};
};
const second = () => {
const CreateBtn1 = document.querySelector("#CreateBtn1");
const Primary1 = document.querySelector("#Primary1");
CreateBtn1.style.backgroundColor = "rgb(150, 180, 255)";
Primary1.style.backgroundColor = "rgb(150, 180, 255)";
CreateBtn1.onmouseover = () => {
CreateBtn1.style.backgroundColor = "rgb(150, 180, 255)";
};
CreateBtn1.onmouseout = () => {
CreateBtn1.style.backgroundColor = "rgb(150, 180, 255)";
};
Primary1.onmouseover = () => {
Primary1.style.backgroundColor = "rgb(150, 180, 255)";
};
Primary1.onmouseout = () => {
Primary1.style.backgroundColor = "rgb(150, 180, 255)";
};
};
const second1 = () => {
const createbtn1 = document.querySelector("#createbtn1");
const primary1 = document.querySelector("#primary1");
createbtn1.style.backgroundColor = "rgb(150, 180, 255)";
primary1.style.backgroundColor = "rgb(150, 180, 255)";
createbtn1.onmouseover = () => {
createbtn1.style.backgroundColor = "rgb(150, 180, 255)";
};
createbtn1.onmouseout = () => {
createbtn1.style.backgroundColor = "rgb(150, 180, 255)";
};
primary1.onmouseover = () => {
primary1.style.backgroundColor = "rgb(150, 180, 255)";
};
primary1.onmouseout = () => {
primary1.style.backgroundColor = "rgb(150, 180, 255)";
};
};
const second2 = () => {
const createbtn2 = document.querySelector("#createbtn2");
const primary2 = document.querySelector("#primary2");
createbtn2.style.backgroundColor = "rgb(150, 180, 255)";
primary2.style.backgroundColor = "rgb(150, 180, 255)";
createbtn2.onmouseover = () => {
createbtn2.style.backgroundColor = "rgb(150, 180, 255)";
};
createbtn2.onmouseout = () => {
createbtn2.style.backgroundColor = "rgb(150, 180, 255)";
};
primary2.onmouseover = () => {
primary2.style.backgroundColor = "rgb(150, 180, 255)";
};
primary2.onmouseout = () => {
primary2.style.backgroundColor = "rgb(150, 180, 255)";
};
};
const second3 = () => {
const createbtn2 = document.querySelector("#createbtn2");
const primary2 = document.querySelector("#primary2");
createbtn2.style.backgroundColor = "rgb(150, 180, 255)";
primary2.style.backgroundColor = "rgb(150, 180, 255)";
createbtn2.onmouseover = () => {
createbtn2.style.backgroundColor = "rgb(150, 180, 255)";
};
createbtn2.onmouseout = () => {
createbtn2.style.backgroundColor = "rgb(150, 180, 255)";
};
primary2.onmouseover = () => {
primary2.style.backgroundColor = "rgb(150, 180, 255)";
};
primary2.onmouseout = () => {
primary2.style.backgroundColor = "rgb(150, 180, 255)";
};
};
const second4 = () => {
const createbtn3 = document.querySelector("#createbtn3");
const primary3 = document.querySelector("#primary3");
createbtn3.style.backgroundColor = "rgb(150, 180, 255)";
primary3.style.backgroundColor = "rgb(150, 180, 255)";
createbtn3.onmouseover = () => {
createbtn3.style.backgroundColor = "rgb(150, 180, 255)";
};
createbtn3.onmouseout = () => {
createbtn3.style.backgroundColor = "rgb(150, 180, 255)";
};
primary3.onmouseover = () => {
primary3.style.backgroundColor = "rgb(150, 180, 255)";
};
primary3.onmouseout = () => {
primary3.style.backgroundColor = "rgb(150, 180, 255)";
};
};

const second5 = () => {
const createbtn4 = document.querySelector("#createbtn4");
const primary4 = document.querySelector("#primary4");
createbtn4.style.backgroundColor = "rgb(150, 180, 255)";
primary4.style.backgroundColor = "rgb(150, 180, 255)";
createbtn4.onmouseover = () => {
createbtn4.style.backgroundColor = "rgb(150, 180, 255)";
};
createbtn4.onmouseout = () => {
createbtn4.style.backgroundColor = "rgb(150, 180, 255)";
};
primary4.onmouseover = () => {
primary4.style.backgroundColor = "rgb(150, 180, 255)";
};
primary4.onmouseout = () => {
primary4.style.backgroundColor = "rgb(150, 180, 255)";
};
};
const spacename1 = () => {
const inputbox1 = document.querySelector(".inputbox1").value;
const showtext = document.querySelector(".showtext");
const regex1 = /^[a-zA-Z]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;
if (regex1.test(inputbox1)) {
showtext.style.color = "rgb(7, 158, 65)";
showtext.innerText = "This name is available";
first();
}
if (regex2.test(inputbox1)) {
showtext.style.color = "red";
showtext.innerText =
  "Please give your Space a longer, more descriptive name.";
second();
}
if (regex3.test(inputbox1)) {
showtext.style.color = "red";
showtext.innerText =
  " Please ensure your Space name contains valid characters.";
second();
}
};
const spacename2 = () => {
const inputbox2 = document.querySelector("#inputbox2").value;
const showtext1 = document.querySelector(".showtext1");
const regex1 = /^[a-zA-Z]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;
if (regex1.test(inputbox2)) {
showtext1.style.color = "rgb(7, 158, 65)";
showtext1.innerText = "This name is available";
first1();
}
if (regex2.test(inputbox2)) {
showtext1.style.color = "red";
showtext1.innerText =
  "Please give your Space a longer, more descriptive name.";
second1();
}
if (regex3.test(inputbox2)) {
showtext1.style.color = "red";
showtext1.innerText =
  " Please ensure your Space name contains valid characters.";
second1();
}
};

const spacename3 = () => {
const inputbox3 = document.querySelector("#inputbox3").value;
const showtext2 = document.querySelector(".showtext2");
const regex1 = /^[a-zA-Z]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;
if (regex1.test(inputbox3)) {
showtext2.style.color = "rgb(7, 158, 65)";
showtext2.innerText = "This name is available";
first3();
}
if (regex2.test(inputbox3)) {
showtext2.style.color = "red";
showtext2.innerText =
  "Please give your Space a longer, more descriptive name.";
second3();
}
if (regex3.test(inputbox3)) {
showtext2.style.color = "red";
showtext2.innerText =
  " Please ensure your Space name contains valid characters.";
second3();
}
};

const spacename4 = () => {
const inputbox4 = document.querySelector("#inputbox4").value;
const showtext3 = document.querySelector(".showtext3");
const regex1 = /^[a-zA-Z]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;
if (regex1.test(inputbox4)) {
showtext3.style.color = "rgb(7, 158, 65)";
showtext3.innerText = "This name is available";
first4();
}
if (regex2.test(inputbox4)) {
showtext3.style.color = "red";
showtext3.innerText =
  "Please give your Space a longer, more descriptive name.";
second4();
}
if (regex3.test(inputbox4)) {
showtext3.style.color = "red";
showtext3.innerText =
  " Please ensure your Space name contains valid characters.";
second4();
}
};

const spacename5 = () => {
const inputbox5 = document.querySelector("#inputbox5").value;
const showtext4 = document.querySelector(".showtext4");
const regex1 = /^[a-zA-Z]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;
if (regex1.test(inputbox5)) {
showtext4.style.color = "rgb(7, 158, 65)";
showtext4.innerText = "This name is available";
first5();
}
if (regex2.test(inputbox5)) {
showtext4.style.color = "red";
showtext4.innerText =
  "Please give your Space a longer, more descriptive name.";
second5();
}
if (regex3.test(inputbox5)) {
showtext4.style.color = "red";
showtext4.innerText =
  " Please ensure your Space name contains valid characters.";
second5();
}
};
function nextpage1() {
const inputbox1 = document.querySelector(".inputbox1").value;
const spacename1=document.querySelector('#spacename1');
const showtext = document.querySelector(".showtext");
const encodedcomponent1=document.querySelector('.encodedcomponent1');
const regex1 = /^[a-zA-Z0-9]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;
if (regex1.test(inputbox1)) {
showtext.style.color = "rgb(7, 158, 65)";
showtext.innerText = "This name is available";
first();
const inputdata = inputbox1;
fetch("/spacecreatedpage", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ inputdata }), // Ensure inputdata is provided
})
  .then((response) => response.json())
  .then((data) => {
    if (data.redirectUrl) {
      window.location.href = data.redirectUrl; // Redirect to /nextpage
    } else {
      console.error("No redirect URL received");
    }
  })
  .catch((err) => {
    console.error("Fetch error:", err);
  });

if (regex2.test(inputbox1)) {
  showtext.style.color = "red";
  showtext.innerText =
    "Please give your Space a longer, more descriptive name.";
  second();
}
if (regex3.test(inputbox1)) {
  showtext.style.color = "red";
  showtext.innerText =
    " Please ensure your Space name contains valid characters.";
  second();
}
}
spacename1.innerHTML=inputbox1;
encodedcomponent1.href=`/nextpage?data=${encodeURIComponent(inputbox1)}`
document.querySelector(".createspace1").style.display = "none";
document.querySelector(".create_space1").style.display = "none";
document.querySelector(".create_space2").style.display = "block";
document.querySelector(".create_space2").style.display = "flex";
closecreatespace();
};
const nextpage2 = () => {
const inputbox2 = document.querySelector("#inputbox2").value;
const spacename2=document.querySelector('#spacename2');
const encodedcomponent2=document.querySelector('.encodedcomponent2');
const showtext1 = document.querySelector(".showtext1");
const regex1 = /^[a-zA-Z0-9]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;

if (regex1.test(inputbox2)) {
showtext1.style.color = "rgb(7, 158, 65)";
showtext1.innerText = "This name is available";
first1();
const inputdata = inputbox2;
fetch("/spacecreatedpage", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ inputdata }), // Ensure inputdata is provided
})
  .then((response) => response.json())
  .then((data) => {
    if (data.redirectUrl) {
      window.location.href = data.redirectUrl; // Redirect to /nextpage
    } else {
      console.error("No redirect URL received");
    }
  })
  .catch((err) => {
    console.error("Fetch error:", err);
  });

if (regex2.test(inputbox2)) {
  showtext1.style.color = "red";
  showtext1.innerText =
    "Please give your Space a longer, more descriptive name.";
  second1();
}
if (regex3.test(inputbox2)) {
  showtext1.style.color = "red";
  showtext1.innerText =
    " Please ensure your Space name contains valid characters.";
  second1();
}
}
spacename2.innerHTML=inputbox2;
encodedcomponent2.href=`/nextpage?data=${encodeURIComponent(inputbox2)}`
document.querySelector(".createspace2").style.display = "none";
document.querySelector(".create_space2").style.display = "none";
document.querySelector(".create_space3").style.display = "block";
document.querySelector(".create_space3").style.display = "flex";
closecreatespace();
};

const nextpage3 = () => {
const inputbox3 = document.querySelector("#inputbox3").value;
const spacename3=document.querySelector('#spacename3');
const showtext2 = document.querySelector(".showtext2");
const encodedcomponent3=document.querySelector('.encodedcomponent3');
const regex1 = /^[a-zA-Z0-9]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;


if (regex1.test(inputbox3)) {
showtext2.style.color = "rgb(7, 158, 65)";
showtext2.innerText = "This name is available";
first2();
const inputdata = inputbox3;
fetch("/spacecreatedpage", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ inputdata }), // Ensure inputdata is provided
})
  .then((response) => response.json())
  .then((data) => {
    if (data.redirectUrl) {
      window.location.href = data.redirectUrl; // Redirect to /nextpage
    } else {
      console.error("No redirect URL received");
    }
  })
  .catch((err) => {
    console.error("Fetch error:", err);
  });

if (regex2.test(inputbox3)) {
  showtext2.style.color = "red";
  showtext2.innerText =
    "Please give your Space a longer, more descriptive name.";
  second2();
}
if (regex3.test(inputbox3)) {
  showtext2.style.color = "red";
  showtext2.innerText =
    " Please ensure your Space name contains valid characters.";
  second2();
}
}
spacename3.innerHTML=inputbox3;
encodedcomponent3.href=`/nextpage?data=${encodeURIComponent(inputbox3)}`
document.querySelector(".createspace3").style.display = "none";
document.querySelector(".create_space3").style.display = "none";
document.querySelector(".create_space4").style.display = "block";
document.querySelector(".create_space4").style.display = "flex";
closecreatespace();
};

const nextpage4 = () => {
const inputbox4 = document.querySelector("#inputbox4").value;
const spacename4=document.querySelector('#spacename4');
const showtext3 = document.querySelector(".showtext3");
const encodedcomponent4=document.querySelector('.encodedcomponent4');
const regex1 = /^[a-zA-Z0-9]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;

if (regex1.test(inputbox4)) {
showtext3.style.color = "rgb(7, 158, 65)";
showtext3.innerText = "This name is available";
first2();
const inputdata = inputbox4;
fetch("/spacecreatedpage", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ inputdata }), // Ensure inputdata is provided
})
  .then((response) => response.json())
  .then((data) => {
    if (data.redirectUrl) {
      window.location.href = data.redirectUrl; // Redirect to /nextpage
    } else {
      console.error("No redirect URL received");
    }
  })
  .catch((err) => {
    console.error("Fetch error:", err);
  });

if (regex2.test(inputbox4)) {
  showtext3.style.color = "red";
  showtext3.innerText =
    "Please give your Space a longer, more descriptive name.";
  second2();
}
if (regex3.test(inputbox4)) {
  showtext3.style.color = "red";
  showtext3.innerText =
    " Please ensure your Space name contains valid characters.";
  second2();
}
}
spacename4.innerHTML=inputbox4;
encodedcomponent4.href=`/nextpage?data=${encodeURIComponent(inputbox4)}`
document.querySelector(".createspace4").style.display = "none";
document.querySelector(".create_space4").style.display = "none";
document.querySelector(".create_space5").style.display = "block";
document.querySelector(".create_space5").style.display = "flex";
closecreatespace();
};

const nextpage5 = () => {
const inputbox5 = document.querySelector("#inputbox5").value;
const spacename5=document.querySelector('#spacename5');
const showtext4 = document.querySelector(".showtext4");
const encodedcomponent5=document.querySelector('.encodedcomponent5');
const regex1 = /^[a-zA-Z0-9]{2,}$/;
const regex2 = /^[a-zA-Z]$/;
const regex3 = /^[0-9@#!*&%$<>{}\[\],.()\=\+\-:;'"]+$/;

if (regex1.test(inputbox5)) {
showtext4.style.color = "rgb(7, 158, 65)";
showtext4.innerText = "This name is available";
first2();
const inputdata = inputbox5;
fetch("/spacecreatedpage", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ inputdata }), // Ensure inputdata is provided
})
  .then((response) => response.json())
  .then((data) => {
    if (data.redirectUrl) {
      window.location.href = data.redirectUrl; // Redirect to /nextpage
    } else {
      console.error("No redirect URL received");
    }
  })
  .catch((err) => {
    console.error("Fetch error:", err);
  });

if (regex2.test(inputbox5)) {
  showtext4.style.color = "red";
  showtext4.innerText =
    "Please give your Space a longer, more descriptive name.";
  second2();
}
if (regex3.test(inputbox5)) {
  showtext4.style.color = "red";
  showtext4.innerText =
    " Please ensure your Space name contains valid characters.";
  second2();
}
}
spacename5.innerHTML=inputbox5;
encodedcomponent5.href=`/nextpage?data=${encodeURIComponent(inputbox5)}`
document.querySelector(".createspace5").style.display = "none";
document.querySelector(".create_space5").style.display = "none";
document.querySelector(".create_space1").style.display = "block";
document.querySelector(".create_space1").style.display = "flex";
closecreatespace();
};
const applybrightnesseffect = () => {
const maincontainer = document.querySelector(".main_container");
const postsection1 = document.querySelector(".postsection1");
const postsection2 = document.querySelector(".postsection2");
const postsection3 = document.querySelector(".postsection3");
const postsection4 = document.querySelector(".postsection4");
const askquestions = document.querySelector(".ask_questions");
const Nav = document.querySelector("#Nav");
postsection1.style.filter = "brightness(0.5)";
postsection2.style.filter = "brightness(0.5)";
postsection3.style.filter = "brightness(0.5)";
postsection4.style.filter = "brightness(0.5)";
askquestions.style.filter = "brightness(0.5)";
Nav.style.filter = "brightness(0.5)";
maincontainer.style.filter = "brightness(0.5)";
};
const spaces1 = () => {
const createspace1 = document.querySelector(".createspace1");
const styleeffect = document.querySelector(".styleeffect");
const askquestions = document.querySelector(".ask_questions");
createspace1.style.display = "block";
styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
askquestions.style.position = "sticky";
applybrightnesseffect();
};
const spaces2 = () => {
const createspace2 = document.querySelector(".createspace2");
const styleeffect = document.querySelector(".styleeffect");
const askquestions = document.querySelector(".ask_questions");
createspace2.style.display = "block";
styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
askquestions.style.position = "sticky";
applybrightnesseffect();
};

const spaces3 = () => {
const createspace3 = document.querySelector(".createspace3");
const styleeffect = document.querySelector(".styleeffect");
const askquestions = document.querySelector(".ask_questions");
createspace3.style.display = "block";
styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
askquestions.style.position = "sticky";
applybrightnesseffect();
};

const spaces4 = () => {
const createspace4 = document.querySelector(".createspace4");
const styleeffect = document.querySelector(".styleeffect");
const askquestions = document.querySelector(".ask_questions");
createspace4.style.display = "block";
styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
askquestions.style.position = "sticky";
applybrightnesseffect();
};

const spaces5 = () => {
const createspace5 = document.querySelector(".createspace5");
const styleeffect = document.querySelector(".styleeffect");
const askquestions = document.querySelector(".ask_questions");
createspace5.style.display = "block";
styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
askquestions.style.position = "sticky";
applybrightnesseffect();
};
const closecreatespace = () => {
const createspace1 = document.querySelector(".createspace1");
const createspace2 = document.querySelector(".createspace2");
const createspace3 = document.querySelector(".createspace3");
const createspace4 = document.querySelector(".createspace4");
const createspace5 = document.querySelector(".createspace5");
const maincontainer = document.querySelector(".main_container");
const styleeffect = document.querySelector(".styleeffect");
const askquestions = document.querySelector(".ask_questions");
const postsection1 = document.querySelector(".postsection1");
const postsection2 = document.querySelector(".postsection2");
const postsection3 = document.querySelector(".postsection3");
const postsection4 = document.querySelector(".postsection4");
const Nav = document.querySelector("#Nav");
createspace1.style.display = "none";
createspace2.style.display = "none";
createspace3.style.display = "none";
createspace4.style.display = "none";
createspace5.style.display = "none";
styleeffect.style.backgroundColor = "";
askquestions.style.position = "";
postsection1.style.filter = "";
postsection2.style.filter = "";
postsection3.style.filter = "";
postsection4.style.filter = "";
askquestions.style.filter = "";
Nav.style.filter = "";
maincontainer.style.filter = "";
};