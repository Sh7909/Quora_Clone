const home = () => {
  localStorage.setItem("runhomefunction", "true");
};
const followingicon = (event) => {
  event.preventDefault();
  const homeicon = document.querySelector("#homeicon");
  const Homeiconline = document.querySelector(".Homeiconline");
  const following = document.querySelector(".following");
  const answer = document.querySelector(".answer");
  const notifications = document.querySelector(".notifications");
  const followingicon = document.querySelectorAll(".followingicon");
  const answericon = document.querySelectorAll(".answericon");
  const notificationicon = document.querySelectorAll(".notificationicon");
  followingicon.forEach((icon) => {
    icon.setAttribute("fill", "rgb(169, 44, 40)");
  });
  following.style.border = "2px solid rgb(169, 44, 40)";
  homeicon.setAttribute("fill", "#666666");
  answericon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  notificationicon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  following.style.display = "block";
  Homeiconline.style.display = "none";
  answer.style.display = "none";
  notifications.style.display = "none";
};
const answericon = () => {
  localStorage.setItem("runAnswerFunction", "true");
};
const notificationicon = () => {
  const homeicon = document.querySelector("#homeicon");
  const Homeiconline = document.querySelector(".Homeiconline");
  const following = document.querySelector(".following");
  const answer = document.querySelector(".answer");
  const notifications = document.querySelector(".notifications");
  const followingicon = document.querySelectorAll(".followingicon");
  const answericon = document.querySelectorAll(".answericon");
  const notificationicon = document.querySelectorAll(".notificationicon");
  notificationicon.forEach((icon) => {
    icon.setAttribute("fill", "rgb(169, 44, 40)");
  });
  notifications.style.border = "2px solid rgb(169, 44, 40)";
  homeicon.setAttribute("fill", "#666666");
  followingicon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  answericon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  following.style.display = "none";
  Homeiconline.style.display = "none";
  answer.style.display = "none";
  notifications.style.display = "block";
};
// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
  const tooltip = document.createElement("div");
  tooltip.className = "tooltip";
  document.body.appendChild(tooltip);
})


// Show tooltip
const tooltip = document.createElement("div");
function showTooltip(event) {
  const text = event.target.getAttribute("data-tooltip");
  if (text) {
    tooltip.textContent = text;
    tooltip.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip.style.top = `${event.pageY + tooltipOffset}px`;
}

// Hide tooltip
function hideTooltip() {
  tooltip.classList.remove("show");
}
// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip2 = document.createElement("div");
tooltip2.className = "tooltiptwo";
document.body.appendChild(tooltip2);
});

// Show tooltip
const tooltip2 = document.createElement("div");
function showTooltip2(event) {
  const text2 = event.target.getAttribute("data-tooltip");
  if (text2) {
    tooltip2.textContent = text2;
    tooltip2.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip2(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip2.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip2.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip2() {
  tooltip2.classList.remove("show");
}
// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip3 = document.createElement("div");
tooltip3.className = "tooltipthree";
document.body.appendChild(tooltip3);
});

// Show tooltip
const tooltip3 = document.createElement("div");
function showTooltip3(event) {
  const text3 = event.target.getAttribute("data-tooltip");
  if (text3) {
    tooltip3.textContent = text3;
    tooltip3.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip3(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip3.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip3.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip3() {
  tooltip3.classList.remove("show");
}
//Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip4 = document.createElement("div");
tooltip4.className = "tooltipfour";
document.body.appendChild(tooltip4);
});

// Show tooltip
const tooltip4 = document.createElement("div");
function showTooltip4(event) {
  const text4 = event.target.getAttribute("data-tooltip");
  if (text4) {
    tooltip4.textContent = text4;
    tooltip4.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip4(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip4.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip4.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip4() {
  tooltip4.classList.remove("show");
}

// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip5 = document.createElement("div");
tooltip5.className = "tooltipfive";
document.body.appendChild(tooltip5);
});

// Show tooltip
const tooltip5 = document.createElement("div");
function showTooltip5(event) {
  const text5 = event.target.getAttribute("data-tooltip");
  if (text5) {
    tooltip5.textContent = text5;
    tooltip5.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip5(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip5.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip5.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip5() {
  tooltip5.classList.remove("show");
}
function tryquora ()
{
  const tryquorasection = document.querySelector(".tryquorasection");
  const postedsection = document.querySelector(".postedsection");
  const bgcolor=document.querySelector('.bgcolor');
  const Nav = document.querySelector("#Nav");
  tryquorasection.style.display = "block";
  Nav.style.filter = "brightness(0.5)";
  bgcolor.style.backgroundColor="gray";
  postedsection.style.filter="brightness(0.5)";
};
const Openlangdivcontainer=()=>{
  const languagediv=document.querySelector('.languagediv');
  const currentDisplay=window.getComputedStyle(languagediv).display;
  if(currentDisplay=="none"){
    languagediv.style.display="block";
  }
  else{
    languagediv.style.display="none";
  }
}
const closelangdiv=()=>{
  const languagediv=document.querySelector('.languagediv');
  languagediv.style.display="none";
}
const openemaildialogbox=()=>{
  const emailcontainer=document.querySelector('.emailcontainer');
  const currentDisplay=window.getComputedStyle(emailcontainer).display;
  if(currentDisplay=="none"){
    emailcontainer.style.display="block";
  }
  else{
    emailcontainer.style.display="none";
  }
}
document.addEventListener("DOMContentLoaded", function () {
  // Create a unique tooltip element
  const tooltipdiv1 = document.createElement("div");
  tooltipdiv1.className = "tooltip1";
  document.body.appendChild(tooltipdiv1);

  // Show tooltip
  function showTooltip1(event) {
    const text7 = event.target.getAttribute("data-tooltip");
    if (text7) {
      tooltipdiv1.textContent = text7;
      tooltipdiv1.style.position = "absolute";
      tooltipdiv1.classList.add("show1");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip1(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltipdiv1.style.left = `${event.pageX + tooltipOffset}px`;
    tooltipdiv1.style.top = `${event.pageY + tooltipOffset}px`;
  }

  // Hide tooltip
  function hideTooltip1() {
    tooltipdiv1.classList.remove("show1");
  }
  document.querySelectorAll("#commentsvg").forEach((element) => {
    element.addEventListener("mouseover", showTooltip1);
    element.addEventListener("mousemove", moveTooltip1);
    element.addEventListener("mouseout", hideTooltip1);
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // Create a unique tooltip element
  const tooltipdiv2 = document.createElement("div");
  tooltipdiv2.className = "tooltip2";
  document.body.appendChild(tooltipdiv2);

  // Show tooltip
  function showTooltip2(event) {
    const text7 = event.target.getAttribute("data-tooltip");
    if (text7) {
      tooltipdiv2.textContent = text7;
      tooltipdiv2.style.position = "absolute";
      tooltipdiv2.classList.add("show2");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip2(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltipdiv2.style.left = `${event.pageX + tooltipOffset}px`;
    tooltipdiv2.style.top = `${event.pageY + tooltipOffset}px`;
  }

  // Hide tooltip
  function hideTooltip2() {
    tooltipdiv2.classList.remove("show2");
  }

  document.querySelectorAll("#sharesvg").forEach((element) => {
    element.addEventListener("mouseover", showTooltip2);
    element.addEventListener("mousemove", moveTooltip2);
    element.addEventListener("mouseout", hideTooltip2);
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // Create a unique tooltip element
  const tooltipdiv3 = document.createElement("div");
  tooltipdiv3.className = "tooltip3";
  document.body.appendChild(tooltipdiv3);

  // Show tooltip
  function showTooltip3(event) {
    const text7 = event.target.getAttribute("data-tooltip");
    if (text7) {
      tooltipdiv3.textContent = text7;
      tooltipdiv3.style.position = "absolute";
      tooltipdiv3.classList.add("show3");
    }
  }

  // Move tooltip along with the cursor
  function moveTooltip3(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltipdiv3.style.left = `${event.pageX + tooltipOffset}px`;
    tooltipdiv3.style.top = `${event.pageY + tooltipOffset}px`;
  }

  // Hide tooltip
  function hideTooltip3() {
    tooltipdiv3.classList.remove("show3");
  }

  document.querySelectorAll("#moresvg").forEach((element) => {
    element.addEventListener("mouseover", showTooltip3);
    element.addEventListener("mousemove", moveTooltip3);
    element.addEventListener("mouseout", hideTooltip3);
  });
});

const upvote = () => {
  // Get the SVG path element
  const upvoteButton = document.querySelector(".upvote_button");
  const liketext = document.querySelector(".liketext");
  const likecounter = document.querySelector(".likecounter1");

  // Get the current fill attribute
  const currentFill = upvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    upvoteButton.setAttribute("fill", "blue");
    liketext.style.color = "blue";
    likecounter.style.color = "blue";
  } else {
    upvoteButton.setAttribute("fill", "none");
    liketext.style.color = "gray";
    likecounter.style.color = "gray";
  }
};
const downvote1 = () => {
  // Get the SVG path element
  const downvoteButton = document.querySelector(".downvote_button");
  // Get the current fill attribute
  const currentFill = downvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    downvoteButton.setAttribute("fill", "rgb(203, 75, 16)");
  } else {
    downvoteButton.setAttribute("fill", "none");
  }
};

const sharenow1 = () => {
  const sharediv = document.querySelector(".sharediv");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const posteddate = document.querySelector("#posteddate");
  const maincontainer = document.querySelector(".main_container");
  const data = document.querySelector("#data");
  const imagename = document.querySelector("#imagename");
  const imgtext = document.querySelector(".imgtext");
  const Pdata = document.querySelector(".Pdata");
  const heading = document.querySelector("#heading");
  const data1 = document.querySelector(".data1");
  const data2 = document.querySelector(".data2");
  const postedtext = document.querySelector("#postedtext");

  sharediv.style.display = "block";
  postcontainer.style.top = "9rem";
  styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "brightness(0.5)";
  postsection2.style.filter = "brightness(0.5)";
  postsection3.style.filter = "brightness(0.5)";
  postsection4.style.filter = "brightness(0.5)";
  askquestions.style.filter = "brightness(0.5)";
  Nav.style.filter = "brightness(0.5)";
  maincontainer.style.filter = "brightness(0.5)";

  const image = document.createElement("img");
  image.style.borderRadius = "2rem";
  image.style.width = "1rem";
  data.innerHTML = "";
  image.src = "../../images/Wonder.png";
  image.alt = "Wonder";
  data.appendChild(image);
  imgtext.innerText = imagename.innerText;
  imgtext.style.fontWeight = "500";
  imgtext.style.fontSize = "0.7rem";
  imgtext.style.position = "absolute";
  imgtext.style.top = "0.5rem";
  imgtext.style.left = "1.3rem";
  imgtext.style.display = "flex";
  imgtext.style.color = "gray";

  const datelist = document.createElement("ul");
  const dated = document.createElement("li");
  datelist.style.color = "gray";
  datelist.appendChild(dated);

  // append data in list
  dated.innerText = posteddate.innerText;
  imgtext.appendChild(datelist);
  Pdata.innerText = heading.innerText;
  data1.style.position = "absolute";
  data1.style.left = "2%";
  data1.innerText = postedtext.innerText;

  const img = document.createElement("img");
  data2.innerHTML = "";
  img.src = "../../images/pic.png";
  data2.append(img);
};
function commentadded() {
  const inputtext = document.querySelector(".inputtext");
  const date = document.querySelector(".date");
  const authname = document.querySelector("#authname");
  const authorimg = document.querySelector("#authorimg");

  // Set current user and date
  date.style.display = "block";
  date.innerText = new Date().toLocaleDateString();
  authorimg.style.display = "block";
  authname.innerText = "You";

  // Add comment text
  const listdata = document.createElement("li");
  listdata.style.display = "flex";
  listdata.setAttribute("class", "data");
  listdata.innerText = inputtext.value;
  inputtext.value = "";

  const commentsdata = document.querySelector(".commentsdata");
  commentsdata.appendChild(listdata);
  // Add SVG (three dots icon)
  const svgNamespace = "http://www.w3.org/2000/svg";
  const svgtag = document.createElementNS(svgNamespace, "svg");
  svgtag.setAttribute("data-bs-toggle", "dropdown"); // Bootstrap toggle
  svgtag.setAttribute("aria-expanded", "false");
  svgtag.setAttribute("width", "24");
  svgtag.setAttribute("height", "24");
  svgtag.setAttribute("viewBox", "0 0 24 24");
  svgtag.setAttribute("fill", "none");
  svgtag.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  svgtag.style.cursor = "pointer";

  const path = document.createElementNS(svgNamespace, "path");
  path.setAttribute(
    "d",
    "M11.25 11.25a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm-7 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm14 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Z"
  );
  path.setAttribute("fill", "#666");
  path.setAttribute("stroke", "#666");
  path.setAttribute("stroke-width", "1.5");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svgtag.appendChild(path);

  // Add dropdown menu
  const dropdownMenu = document.createElement("ul");
  dropdownMenu.classList.add("dropdown-menu");

  svgtag.onclick=()=>{
    if(dropdownMenu.style.display=="none"){
      console.log("jhhkhk")
      dropdownMenu.style.position = "absolute"; 
      dropdownMenu.style.display="block";
    }
    else{
      dropdownMenu.style.display="none";
    }
  }

  // Edit button

  const editItem = document.createElement("li");
  const editLink = document.createElement("a");
  editLink.classList.add("dropdown-item");
  editLink.style.cursor = "pointer";
  editLink.innerText = "Edit";
  editLink.onclick = () => {
    listdata.remove();
    listdata.appendChild(wrapperDiv);
    commentsdata.appendChild(listdata);
    // create input tag
    const inputtag = document.createElement("input");
    inputtag.setAttribute("type", "text");
    inputtag.setAttribute("class", "editcomment");
    commentsdata.appendChild(inputtag);

    //create buttons

    const buttondiv = document.createElement("div");
    const Cancelbtn = document.createElement("button");
    const Updatebtn = document.createElement("button");
    Cancelbtn.setAttribute("class", "btn");
    Cancelbtn.style.height = "2.5rem";
    Cancelbtn.innerText = "Cancel";
    Updatebtn.setAttribute("class", "btn btn-primary");
    Updatebtn.style.height = "2.5rem";
    Updatebtn.innerText = "Update";
    buttondiv.style.marginTop = "2.6rem";
    buttondiv.appendChild(Cancelbtn);
    buttondiv.appendChild(Updatebtn);
    commentsdata.appendChild(buttondiv);

    // Update text
    Updatebtn.onclick = () => {
      const editcomment = document.querySelector(".editcomment");
      const edittext = editcomment.value;
      const promptvalue = prompt("Are you sure?");

      if (editcomment) editcomment.remove();
      if (buttondiv) buttondiv.remove();

      if (promptvalue && promptvalue.trim().toLowerCase() === "yes") {
        // User confirmed with "yes"
        listdata.innerText = edittext; // Update the comment text
        listdata.appendChild(wrapperDiv); // Reattach the dropdown and SVG
        console.log("Changes saved.");

        // Hide the input box and button div
        editcomment.style.display = "none";
        buttondiv.style.display = "none";
      }
    };
    // cancel text
    Cancelbtn.onclick = () => {
      const editcomment = document.querySelector(".editcomment");
      if (editcomment) editcomment.remove();
      if (buttondiv) buttondiv.remove();

      editcomment.style.display = "none";
      buttondiv.style.display = "none";
    };
  };
  editItem.appendChild(editLink);
  dropdownMenu.appendChild(editItem);

  // Delete button
  const deleteItem = document.createElement("li");
  const deleteLink = document.createElement("a");
  deleteLink.classList.add("dropdown-item");
  deleteLink.style.cursor = "pointer";
  deleteLink.innerText = "Delete";
  deleteLink.onclick = () => {
    listdata.remove(); // Remove the comment
    dropdownMenu.remove(); // Remove the dropdown
    svgtag.remove();
  };
  deleteItem.appendChild(deleteLink);
  dropdownMenu.appendChild(deleteItem);

  // Attach the dropdown to the SVG
  const wrapperDiv = document.createElement("div");
  wrapperDiv.style.position = "relative";
  wrapperDiv.appendChild(dropdownMenu);
  wrapperDiv.appendChild(svgtag);
  listdata.appendChild(wrapperDiv);
};
const editpost = () => {
  const editpost = document.querySelector(".editpost");
  const bgcolor = document.querySelector(".bgcolor");
  const postedsection = document.querySelector(".postedsection");
  const likecontainer2 = document.querySelector(".likecontainer2");
  const addcomments = document.querySelector(".addcomments");
  const addcomment = document.querySelector(".addcomment");
  const inputtext = document.querySelector(".inputtext");
  const inputbox2 = document.querySelector(".inputbox2");
  const imgstyling = document.querySelector(".imgstyling");

  imgstyling.innerText = "";
  editpost.style.display = "block";
  imgstyling.style.backgroundColor = "rgb(56, 56, 56)";
  bgcolor.style.backgroundColor = "rgb(56, 56, 56)";
  inputtext.style.backgroundColor = "rgb(56, 56, 56)";
  inputbox2.style.backgroundColor = "rgb(56, 56, 56)";
  likecontainer2.style.backgroundColor = "rgb(56, 56, 56)";
  postedsection.style.backgroundColor = "rgb(56, 56, 56)";
  addcomments.style.backgroundColor = "rgb(56, 56, 56)";
  addcomment.style.backgroundColor = "rgb(56, 56, 56)";
};
const hidenow = () => {
  const editpost = document.querySelector(".editpost");
  const bgcolor = document.querySelector(".bgcolor");
  const postedsection = document.querySelector(".postedsection");
  const likecontainer2 = document.querySelector(".likecontainer2");
  const addcomments = document.querySelector(".addcomments");
  const addcomment = document.querySelector(".addcomment");
  const inputtext = document.querySelector(".inputtext");
  const inputbox2 = document.querySelector(".inputbox2");
  const imgstyling = document.querySelector(".imgstyling");
  editpost.style.display = "none";
  bgcolor.style.backgroundColor = "";
  inputtext.style.backgroundColor = "";
  inputbox2.style.backgroundColor = "";
  likecontainer2.style.backgroundColor = "";
  postedsection.style.backgroundColor = "";
  addcomments.style.backgroundColor = "";
  addcomment.style.backgroundColor = "";
  imgstyling.style.backgroundColor = "";
};
const changedata = () => {
  const editarea = document.querySelector("#editarea");
  const posteddata1 = document.querySelector(".posteddata1");
  const postedsection = document.querySelector(".postedsection");
  const imagesection = document.querySelector(".imagesection");
  const imgstyling = document.querySelector(".imgstyling");
  const ImageElement = document.querySelectorAll(".imagesection img");
  const addcomments = document.querySelector(".addcomments");
  const likecontainer = document.querySelector(".likecontainer");
  const changeedittext = document.querySelector(".changeedittext");
  changeedittext.innerText = editarea.value.trim();
  posteddata1.innerText = editarea.value.trim();
  if (imagesection.innerHTML != "") {
    ImageElement.forEach((element) => {
      imgstyling.append(element);
    });
    postedsection.style.height = "20rem";
    addcomments.style.top = "15rem";
    likecontainer.style.top = "11rem";
  }
  hidenow();
};
const showstyles = () => {
  const shownow = document.querySelector(".shownow");
  const photosvg = document.querySelector("#photosvg");
  const fontstylessvg = document.querySelector("#fontstylessvg");
  shownow.style.display = "block";
  shownow.style.display = "flex";
  photosvg.style.display = "none";
  fontstylessvg.style.display = "none";
};
const togglefnc = () => {
  const dropdowntogglebtn = document.querySelector(".dropdowntogglebtn");
  const shownow = document.querySelector(".shownow");
  const photosvg = document.querySelector("#photosvg");
  const fontstylessvg = document.querySelector("#fontstylessvg");
  if (dropdowntogglebtn.style.display == "none") {
    shownow.style.display = "block";
    photosvg.style.display = "none";
    fontstylessvg.style.display = "none";
  } else {
    shownow.style.display = "none";
    photosvg.style.display = "block";
    fontstylessvg.style.display = "block";
  }
};
const bold = () => {
  const editarea = document.querySelector("#editarea");
  editarea.addEventListener("focus", () => {
    editarea.style.fontWeight = "bold";
  });
};
const italic = () => {
  const editarea = document.querySelector("#editarea");
  editarea.addEventListener("focus", () => {
    editarea.style.fontStyle = "italic";
  });
};
const invertedcomma = () => {
  const editarea = document.querySelector("#editarea");
  editarea.textContent += `""`;
};
const attherate = () => {
  const editarea = document.querySelector("#editarea");
  editarea.textContent += `@`;
};
const curlybraces = () => {
  const editarea = document.querySelector("#editarea");
  editarea.textContent += `{}`;
};
const inputimg = () => {
  const fileInput = document.querySelector("#fileInput");
  const imagesection = document.querySelector(".imagesection");

  fileInput.click();

  fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0]; // Get the selected file

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e) {
        const img = document.createElement("img");
        img.src = e.target.result; // Base64 image URL
        img.style.maxWidth = "20%"; // Ensure the image fits
        document.querySelector(".imagesection").appendChild(img); // Insert image
        imagesection.style.display = "block";
      };
      reader.readAsDataURL(file); // Convert image to Base64
    }
    fileInput.value = "";
  });
};
const deletepost = () => {
  const postedsection = document.querySelector(".postedsection");
  const addcomments = document.querySelector(".addcomments");
  const deletedpost = document.querySelector(".deletedpost");
  const promptbox = window.prompt("Are you sure?");
  if (promptbox == "yes" || promptbox == "YES") {
    postedsection.style.display = "none";
    addcomments.style.display = "none";
    deletedpost.style.display = "block";
  } else {
    deletedpost.style.display = "none";
    postedsection.style.display = "block";
    addcomments.style.display = "block";
  }
};
const opendropdownMenu=()=>{
  const dropdownMenu=document.querySelector('#dropdownMenu');
  const currentDisplay=window.getComputedStyle(dropdownMenu).display;
  if(currentDisplay=="none"){
    dropdownMenu.style.display="block";
  }
  else{
    dropdownMenu.style.display="none";
  }
}
const closetryquora=()=>{
  const tryquorasection = document.querySelector(".tryquorasection");
  const postedsection = document.querySelector(".postedsection");
  const bgcolor=document.querySelector('.bgcolor');
  const Nav=document.querySelector('#Nav');
  Nav.style.filter="";
  tryquorasection.style.display = "none";
  Nav.style.filter = "";
  bgcolor.style.backgroundColor="";
  postedsection.style.filter="";
}
const monthlypriceshow=()=>{
  const pricedetails=document.querySelector(".pricedetails");
  const tryquora6=document.querySelector(".tryquora6");
  const tryquora7=document.querySelector(".tryquora7");
  const yearlytxt=document.querySelector(".yearlytxt");
  const pricediv1=document.querySelector(".pricediv1");
  pricedetails.innerText="$6.99/mo";
  tryquora6.style.border="1px solid gainsboro";
  tryquora6.style.backgroundColor="white";
  yearlytxt.style.color="black";
  pricediv1.style.color="black";
  tryquora7.style.border="1px solid rgb(46, 105, 255)";
  tryquora7.style.backgroundColor="rgb(247,247,247)";
}
const yearlypriceshow=()=>{
  const pricedetails=document.querySelector(".pricedetails");
  const tryquora6=document.querySelector(".tryquora6");
  const tryquora7=document.querySelector(".tryquora7");
  const yearlytxt=document.querySelector(".yearlytxt");
  const pricediv1=document.querySelector(".pricediv1");
  const monthlytxt=document.querySelector(".monthlytxt");
  const pricediv2=document.querySelector(".pricediv2");

  pricedetails.innerText="$47.88/yr";
  tryquora7.style.border="1px solid gainsboro";
  tryquora7.style.backgroundColor="white";
  yearlytxt.style.color="rgb(46, 105, 255)";
  pricediv1.style.color="rgb(46, 105, 255)";
  tryquora6.style.border="1px solid rgb(46, 105, 255)";
  tryquora6.style.backgroundColor="rgb(247,247,247)"; 
  monthlytxt.style.color="black";
  pricediv2.style.color="black";
}
const opendialog = () => {
  const questiondialogbox = document.querySelector(".questiondialogbox");
  const spacecontainer=document.querySelector(".spacecontainer");
  const Nav = document.querySelector("#Nav");
  questiondialogbox.style.display = "block";
  Nav.style.filter = "brightness(0.5)";
  spacecontainer.style.filter="brightness(0.5)";
};