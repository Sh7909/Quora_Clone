const home = () => {
    localStorage.setItem("runhomefunction", "true");
  };
  const followingicon = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    following.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "block";
    Homeiconline.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "none";
  };
  const answericon = () => {
    localStorage.setItem("runAnswerFunction", "true");
  };
  const notificationicon = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    notifications.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "none";
    Homeiconline.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "block";
  };
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
    const tooltip = document.createElement("div");
    tooltip.className = "tooltip";
    document.body.appendChild(tooltip);
  })
  
  
  // Show tooltip
  const tooltip = document.createElement("div");
  function showTooltip(event) {
    const text = event.target.getAttribute("data-tooltip");
    if (text) {
      tooltip.textContent = text;
      tooltip.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  // Hide tooltip
  function hideTooltip() {
    tooltip.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
    tooltip2.className = "tooltiptwo";
    document.body.appendChild(tooltip2);
  })
  const tooltip2 = document.createElement("div");
  
  // Show tooltip
  function showTooltip2(event) {
    const text2 = event.target.getAttribute("data-tooltip");
    if (text2) {
      tooltip2.textContent = text2;
      tooltip2.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip2(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip2.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip2.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  //Hide tooltip
  function hideTooltip2() {
    tooltip2.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
    tooltip3.className = "tooltipthree";
    document.body.appendChild(tooltip3);
  });
  // Show tooltip
  const tooltip3 = document.createElement("div");
  function showTooltip3(event) {
    const text3 = event.target.getAttribute("data-tooltip");
    if (text3) {
      tooltip3.textContent = text3;
      tooltip3.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip3(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip3.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip3.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  //Hide tooltip
  function hideTooltip3() {
    tooltip3.classList.remove("show");
  }
  // Create a tooltip element
  document.addEventListener('DOMContentLoaded',()=>{
    const tooltip5 = document.createElement("div");
    tooltip5.className = "tooltipfive";
    document.body.appendChild(tooltip5);
  })
  
  
  // Show tooltip
  const tooltip5 = document.createElement("div");
  function showTooltip5(event) {
    const text5 = event.target.getAttribute("data-tooltip");
    if (text5) {
      tooltip5.textContent = text5;
      tooltip5.classList.add("show");
    }
  }
  
  // Move tooltip along with the cursor
  function moveTooltip5(event) {
    const tooltipOffset = 10; // Offset from cursor
    tooltip5.style.left = `${event.pageX + tooltipOffset}px`;
    tooltip5.style.top = `${event.pageY + tooltipOffset}px`;
  }
  
  //Hide tooltip
  function hideTooltip5() {
    tooltip5.classList.remove("show");
  }
  function tryquora() {
    const tryquorasection = document.querySelector(".tryquorasection");
    const seconddiv = document.querySelector(".seconddiv");
    const answerpage=document.querySelector('.answerpage');
    const Anspage=document.querySelector('.Anspage');
    const Nav=document.querySelector('#Nav');
    Nav.style.filter="brightness(0.5)";
    tryquorasection.style.display = "block";
   seconddiv.style.backgroundColor = "rgb(128, 128, 128)";
   answerpage.style.backgroundColor = "rgb(128, 128, 128)";
   Anspage.style.backgroundColor = "rgb(128, 128, 128)";
  
  };
  
  window.onload = () => {
    if (localStorage.getItem("runAnswerFunction") === "true") {
      localStorage.removeItem("runAnswerFunction");
      myCustomFunction1();
    }
  
    if (localStorage.getItem("runhomefunction") === "true") {
      localStorage.removeItem("runhomefunction");
      myCustomFunction2();
    }
  };
  
  const myCustomFunction1 = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "rgb(169, 44, 40)");
    });
    answer.style.border = "2px solid rgb(169, 44, 40)";
    homeicon.setAttribute("fill", "#666666");
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "none";
    Homeiconline.style.display = "none";
    answer.style.display = "block";
    notifications.style.display = "none";
  };
  const myCustomFunction2 = () => {
    const homeicon = document.querySelector("#homeicon");
    const Homeiconline = document.querySelector(".Homeiconline");
    const following = document.querySelector(".following");
    const answer = document.querySelector(".answer");
    const notifications = document.querySelector(".notifications");
    const followingicon = document.querySelectorAll(".followingicon");
    const answericon = document.querySelectorAll(".answericon");
    const notificationicon = document.querySelectorAll(".notificationicon");
    homeicon.setAttribute("fill", "rgb(169, 44, 40)");
    Homeiconline.style.display = "block";
    Homeiconline.style.border = "2px solid rgb(169, 44, 40)";
    followingicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    answericon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    notificationicon.forEach((icon) => {
      icon.setAttribute("fill", "#666666");
    });
    following.style.display = "none";
    answer.style.display = "none";
    notifications.style.display = "none";
  };
  let counter1 = 0;
  let counter2 = 0;
  let counter3 = 0;
  let counter4 = 0;
  let counter5 = 0;
  let counter6 = 0;
  let counter7 = 0;
  
  const startcounter1 = () => {
    const value1 = document.querySelector(".value1");
    const followcounter1 = document.querySelector(".followcounter1");
    followcounter1.style.listStyleType = "disc";
    value1.innerHTML = counter1++;
  };
  const startcounter2 = () => {
    const value2 = document.querySelector("#value2");
    const followcounter2 = document.querySelector(".followcounter2");
    followcounter2.style.listStyleType = "disc";
    value2.innerHTML = counter2++;
  };
  const startcounter3 = () => {
    const value3 = document.querySelector("#value3");
    const followcounter3 = document.querySelector(".followcounter3");
    followcounter3.style.listStyleType = "disc";
    value3.innerHTML = counter3++;
  };
  const startcounter4 = () => {
    const value4 = document.querySelector("#value4");
    const followcounter4 = document.querySelector(".followcounter4");
    followcounter4.style.listStyleType = "disc";
    value4.innerHTML = counter4++;
  };
  const startcounter5 = () => {
    const value5 = document.querySelector("#value5");
    const followcounter5 = document.querySelector(".followcounter5");
    followcounter5.style.listStyleType = "disc";
    value5.innerHTML = counter5++;
  };
  const startcounter6 = () => {
    const value6 = document.querySelector("#value6");
    const followcounter6 = document.querySelector(".followcounter6");
    followcounter6.style.listStyleType = "disc";
    value6.innerHTML = counter6++;
  };
  const startcounter7 = () => {
    const value7 = document.querySelector("#value7");
    const followcounter7 = document.querySelector(".followcounter7");
    followcounter7.style.listStyleType = "disc";
    value7.innerHTML = counter7++;
  };
  const closenow1 = () => {
    const Question1 = document.querySelector(".Question1");
    const Question2 = document.querySelector(".Question2");
    const First = document.querySelector(".First");
    const Second = document.querySelector(".Second");
    Question1.style.display = "none";
    Question2.style.top = "2%";
    First.style.display = "none";
    Second.style.marginTop = "-4rem";
  };
  const closenow2 = () => {
    const Question2 = document.querySelector(".Question2");
    const Question3 = document.querySelector(".Question3");
    const Second = document.querySelector(".Second");
    const Third = document.querySelector(".Third");
    Question2.style.display = "none";
    Second.style.display = "none";
    Question3.style.top = "22%";
    Third.style.marginTop = "-3rem";
  };
  const closenow3 = () => {
    const Question3 = document.querySelector(".Question3");
    const Question4 = document.querySelector(".Question4");
    const Third = document.querySelector(".Third");
    const Four = document.querySelector(".Four");
    Question3.style.display = "none";
    Question4.style.top = "44%";
    Third.style.display = "none";
    Four.style.marginTop = "-4rem";
  };
  const closenow4 = () => {
    const Question4 = document.querySelector(".Question4");
    const Morebutton = document.querySelector(".Morebutton");
    const Four = document.querySelector(".Four");
    Question4.style.display = "none";
    Four.style.display = "none";
    Morebutton.style.top = "-6rem";
  };
  const closenow5 = () => {
    const Question5 = document.querySelector(".Question5");
    const Question6 = document.querySelector(".Question6");
    const lineno1 = document.querySelector("#lineno1");
    const lineno2 = document.querySelector("#lineno2");
    Question5.style.display = "none";
    Question6.style.top = "80%";
    lineno1.style.display = "none";
    lineno2.style.marginTop = "-2rem";
  };
  const closenow6 = () => {
    const Question6 = document.querySelector(".Question6");
    const Question7 = document.querySelector(".Question7");
    const lineno2 = document.querySelector("#lineno2");
    Question6.style.display = "none";
    Question7.style.marginTop = "-5rem";
    lineno2.style.display = "none";
  };
  const closenow7 = () => {
    const Question7 = document.querySelector(".Question7");
    Question7.style.display = "none";
  };
  const more = () => {
    const Morebutton = document.querySelector(".Morebutton");
    const Question5 = document.querySelector(".Question5");
    const Question6 = document.querySelector(".Question6");
    const Question7 = document.querySelector(".Question7");
    const lineno1 = document.querySelector("#lineno1");
    const lineno2 = document.querySelector("#lineno2");
    const seconddiv = document.querySelector(".seconddiv");
    Morebutton.style.display = "none";
    Question5.style.display = "block";
    Question6.style.display = "block";
    Question7.style.display = "block";
    lineno1.style.display = "block";
    lineno2.style.display = "block";
    seconddiv.style.height = "67rem";
  };
  const changes = () => {
    const answerpage = document.querySelector(".answerpage");
    const seconddiv = document.querySelector(".seconddiv");
    const Nav = document.querySelector("#Nav");
    const Anspage = document.querySelector(".Anspage");
    Nav.style.filter = "brightness(0.5)";
    answerpage.style.backgroundColor = "gray";
    seconddiv.style.backgroundColor = "gray";
    Anspage.style.backgroundColor = "gray";
    answerpage.style.top = "9%";
  };
  const opendialog1 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const firstquestion = document.querySelector(".firstquestion");
    const showquestions = document.querySelector(".showquestions");
    questiondialogbox.style.display = "block";
    showquestions.innerText = firstquestion.innerText;
    changes();
  };
  
  const opendialog2 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const secondquestion = document.querySelector(".secondquestion");
    const showquestions = document.querySelector(".showquestions");
    questiondialogbox.style.display = "block";
    showquestions.innerText = "";
    showquestions.innerText = secondquestion.innerText;
    changes();
  };
  
  const opendialog3 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const showquestions = document.querySelector(".showquestions");
    const Thirdquestion = document.querySelector(".Thirdquestion");
    questiondialogbox.style.display = "block";
    showquestions.innerText = "";
    showquestions.innerText = Thirdquestion.innerText;
    changes();
  };
  
  const opendialog4 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const showquestions = document.querySelector(".showquestions");
    const Fourthquestion = document.querySelector(".Fourthquestion");
    questiondialogbox.style.display = "block";
    showquestions.innerText = "";
    showquestions.innerText = Fourthquestion.innerText;
    changes();
  };
  
  const opendialog5 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const showquestions = document.querySelector(".showquestions");
    const Fifthquestion = document.querySelector(".Fifthquestion");
    questiondialogbox.style.display = "block";
    showquestions.innerText = "";
    showquestions.innerText = Fifthquestion.innerText;
    changes();
  };
  
  const opendialog6 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const showquestions = document.querySelector(".showquestions");
    const sixthquestion = document.querySelector(".sixthquestion");
    questiondialogbox.style.display = "block";
    showquestions.innerText = "";
    showquestions.innerText = sixthquestion.innerText;
    changes();
  };
  
  const opendialog7 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const showquestions = document.querySelector(".showquestions");
    const seventhquestion = document.querySelector(".seventhquestion");
    questiondialogbox.style.display = "block";
    showquestions.innerText = "";
    showquestions.innerText = seventhquestion.innerText;
    changes();
  };
  
  const close1 = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const answerpage = document.querySelector(".answerpage");
    const seconddiv = document.querySelector(".seconddiv");
    const Nav = document.querySelector("#Nav");
    const Anspage = document.querySelector(".Anspage");
    questiondialogbox.style.display = "none";
    Nav.style.filter = "";
    answerpage.style.backgroundColor = "";
    seconddiv.style.backgroundColor = "";
    answerpage.style.top = "";
    Anspage.style.backgroundColor = "";
  };
  const createpost = () => {
    const postdiv = document.querySelector("#postdiv");
    const Enable = document.querySelector("#Enable");
    postdiv.style.display = "none";
    Enable.style.display = "block";
  };
  const exec2 = () => {
    const textarea = document.querySelector("#Enable");
    const postbtn = document.querySelector("#postbtn");
  
    if (textarea.value.trim() === "") {
      postbtn.style.opacity = 0.4;
      postbtn.style.cursor = "default";
    } else {
      postbtn.style.opacity = 1;
      postbtn.style.cursor = "pointer";
    }
  };
  const showstyles = () => {
    const shownow = document.querySelector(".shownow");
    const photosvg = document.querySelector("#photosvg");
    const fontstylessvg = document.querySelector("#fontstylessvg");
    shownow.style.display = "block";
    shownow.style.display = "flex";
    photosvg.style.display = "none";
    fontstylessvg.style.display = "none";
  };
  const togglefnc = () => {
    const dropdowntogglebtn = document.querySelector(".dropdowntogglebtn");
    const shownow = document.querySelector(".shownow");
    const photosvg = document.querySelector("#photosvg");
    const fontstylessvg = document.querySelector("#fontstylessvg");
    if (dropdowntogglebtn.style.display == "none") {
      shownow.style.display = "block";
      photosvg.style.display = "none";
      fontstylessvg.style.display = "none";
    } else {
      shownow.style.display = "none";
      photosvg.style.display = "block";
      fontstylessvg.style.display = "block";
    }
  };
  const showmenudata=()=>{
    const droplist=document.querySelector('#droplist');
    const currentDisplay=window.getComputedStyle(droplist).display;
    if(currentDisplay=="none"){
      droplist.style.display="block";
    }
    else{
      droplist.style.display="none";
    }
  }
  const menu1 = () => {
    const img1 = document.querySelector("#img1");
    const img2 = document.querySelector("#img2");
    const change = document.querySelector("#change");
    const menu1 = document.querySelector(".menu1");
    img1.style.display = "block";
    img2.style.display = "none";
    change.innerText = menu1.innerText;
  };
  const menu2 = () => {
    const img1 = document.querySelector("#img1");
    const img2 = document.querySelector("#img2");
    const menu2 = document.querySelector(".menu2");
    const change = document.querySelector("#change");
    img1.style.display = "none";
    img2.style.display = "block";
    change.innerText = menu2.innerText;
  };
  const inputimg = () => {
    const fileInput = document.querySelector("#fileInput");
    const imagesection = document.querySelector(".imagesection");
  
    fileInput.click();
  
    fileInput.addEventListener("change", function (event) {
      const file = event.target.files[0]; // Get the selected file
  
      if (file) {
        const reader = new FileReader();
  
        reader.onload = function (e) {
          const img = document.createElement("img");
          img.src = e.target.result; // Base64 image URL
          img.style.maxWidth = "20%"; // Ensure the image fits
          document.querySelector(".imagesection").appendChild(img); // Insert image
          imagesection.style.display = "block";
        };
        reader.readAsDataURL(file); // Convert image to Base64
      }
      fileInput.value = "";
    });
  };
  
    const invertedcomma = () => {
      const Enable = document.querySelector("#Enable");
      if (Enable) {
        Enable.value += `""`;
      }
    };
    const attherate = () => {
      const Enable = document.querySelector("#Enable");
  
      if (Enable) {
        Enable.value = Enable.value.trim(); // Remove extra spaces
        Enable.value += "@";
  
        // Delay and remove {} if they appear
        setTimeout(() => {
          Enable.value = Enable.value.replace(/\{\}/g, "");
        }, 1);
      }
    };
  
  
    const curlybraces = () => {
      const Enable = document.querySelector("#Enable");
  
      if (Enable) {
        Enable.value = Enable.value.trim();
        Enable.value += "{}";
      }
    };
  
  const senddata = () => {
    const getdata = document.querySelector("#Enable").value;
    const imageElements = document.querySelectorAll(".imagesection img");
  
    const formData = new FormData();
    formData.append("getdata", getdata);
  
    let imagePromises = [];
  
    imageElements.forEach((imageElement, index) => {
      imagePromises.push(
        fetch(imageElement.src)
          .then((response) => response.blob())
          .then((blob) => {
            const file = new File([blob], `uploaded_image_${index}.jpg`, {
              type: blob.type,
            });
            formData.append("images", file);
          })
      );
    });
  
    Promise.all(imagePromises)
      .then(() => {
        return fetch("/postdata", {
          method: "POST",
          body: formData,
        });
      })
      .then((response) => {
        if (response.redirected) {
          window.location.href = response.url;
        }
      })
      .catch((err) => console.error("Error:", err));
  };
  const closetryquora=()=>{
    const tryquorasection = document.querySelector(".tryquorasection");
    const seconddiv = document.querySelector(".seconddiv");
    const answerpage=document.querySelector('.answerpage');
    const Anspage=document.querySelector('.Anspage');
    const Nav=document.querySelector('#Nav');
    Nav.style.filter="";
    tryquorasection.style.display = "none";
   seconddiv.style.backgroundColor = "";
   answerpage.style.backgroundColor = "";
   Anspage.style.backgroundColor = "";
  
  }
  const monthlypriceshow=()=>{
    const pricedetails=document.querySelector(".pricedetails");
    const tryquora6=document.querySelector(".tryquora6");
    const tryquora7=document.querySelector(".tryquora7");
    const yearlytxt=document.querySelector(".yearlytxt");
    const pricediv1=document.querySelector(".pricediv1");
    pricedetails.innerText="$6.99/mo";
    tryquora6.style.border="1px solid gainsboro";
    tryquora6.style.backgroundColor="white";
    yearlytxt.style.color="black";
    pricediv1.style.color="black";
    tryquora7.style.border="1px solid rgb(46, 105, 255)";
    tryquora7.style.backgroundColor="rgb(247,247,247)";
  }
  const yearlypriceshow=()=>{
    const pricedetails=document.querySelector(".pricedetails");
    const tryquora6=document.querySelector(".tryquora6");
    const tryquora7=document.querySelector(".tryquora7");
    const yearlytxt=document.querySelector(".yearlytxt");
    const pricediv1=document.querySelector(".pricediv1");
    const monthlytxt=document.querySelector(".monthlytxt");
    const pricediv2=document.querySelector(".pricediv2");
  
    pricedetails.innerText="$47.88/yr";
    tryquora7.style.border="1px solid gainsboro";
    tryquora7.style.backgroundColor="white";
    yearlytxt.style.color="rgb(46, 105, 255)";
    pricediv1.style.color="rgb(46, 105, 255)";
    tryquora6.style.border="1px solid rgb(46, 105, 255)";
    tryquora6.style.backgroundColor="rgb(247,247,247)"; 
    monthlytxt.style.color="black";
    pricediv2.style.color="black";
  }
  const Openlangdivcontainer=()=>{
    const languagediv=document.querySelector('.languagediv');
    const currentDisplay=window.getComputedStyle(languagediv).display;
    if(currentDisplay=="none"){
      languagediv.style.display="block";
    }
    else{
      languagediv.style.display="none";
    }
  }
  const closelangdiv=()=>{
    const languagediv=document.querySelector('.languagediv');
    languagediv.style.display="none";
  }
  const opendropdowndialogbox=()=>{
    const dropdownMenu=document.querySelector('#dropdownMenu');
    const currentDisplay=window.getComputedStyle(dropdownMenu).display;
    if(currentDisplay=="none"){
      dropdownMenu.style.display="block";
    }
    else{
      dropdownMenu.style.display="none";
    }
  }
  const opendialog = () => {
    const questiondialogbox = document.querySelector(".questiondialogbox");
    const Nav = document.querySelector("#Nav");
    questiondialogbox.style.display = "block";
    const seconddiv = document.querySelector(".seconddiv");
    const answerpage=document.querySelector('.answerpage');
    const Anspage=document.querySelector('.Anspage');
   seconddiv.style.backgroundColor = "rgb(128, 128, 128)";
   answerpage.style.backgroundColor = "rgb(128, 128, 128)";
   Anspage.style.backgroundColor = "rgb(128, 128, 128)";
    Nav.style.filter = "brightness(0.5)";
  };
  const startnow = () => {
    const questionstart = document.querySelector("#questionstart");
    const after = document.querySelector("#after");
    questionstart.style.display = "none";
    after.style.display = "block";
  };
  const hovercolor = () => {
    const line = document.querySelector(".line");
    line.style.border = "1px solid blue";
  };
  const hoveroutcolor = () => {
    const line = document.querySelector(".line");
    line.style.border = "";
  };
  const exec = () => {
    const textarea = document.querySelector("#after");
    const line = document.querySelector(".line");
    const addquestion = document.querySelector("#addquestion");
  
    // Get the scroll height (amount of overflow) of the textarea
    const textHeight = textarea.scrollHeight;
  
    // Adjust the position of the <hr> based on the textarea's height
    // Add some spacing
  
    if (textarea.value.trim() === "") {
      addquestion.style.opacity = 0.4;
      line.style.top = "10%";
    } else {
      addquestion.style.cursor="pointer";
      addquestion.style.opacity = 1;
      line.style.top = `${textHeight + 0.2}px`;
    }
  };
  const questionbox = () => {
    const createpost = document.querySelector(".createpost");
    const line2 = document.querySelector(".line2");
    const box6 = document.querySelector(".box6");
    const box9 = document.querySelector(".box9");
    const box10 = document.querySelector(".box10");
    const box11 = document.querySelector(".box11");
    const text3 = document.querySelector(".text3");
    const box12 = document.querySelector(".box12");
    const startquestion = document.querySelector(".startquestion");
    const Boxtwo = document.querySelector(".Boxtwo");
    const boxtwo = document.querySelector(".boxtwo");
    createpost.style.display = "none";
    box9.style.opacity = 1;
    box10.style.opacity = 0;
    line2.style.display = "none";
    box11.style.display = "block";
    box12.style.display = "block";
    box12.style.display = "flex";
    text3.style.display = "none";
    Boxtwo.style.display = "none";
    boxtwo.style.display = "block";
    boxtwo.style.display = "flex";
    startquestion.style.display = "block";
    box6.onmouseover = () => {
      box6.style.backgroundColor = "white";
    };
    box6.onmouseout = () => {
      box6.style.backgroundColor = "white";
    };
  };
  const postdiv = () => {
    const line2 = document.querySelector(".line2");
    const box6 = document.querySelector(".box6");
    const box7 = document.querySelector(".box7");
    const box9 = document.querySelector(".box9");
    const box10 = document.querySelector(".box10");
    const box12 = document.querySelector(".box12");
    const createpost = document.querySelector(".createpost");
    const text3 = document.querySelector(".text3");
    const boxtwo = document.querySelector(".boxtwo");
    const Boxtwo = document.querySelector(".Boxtwo");
    const profilesection = document.querySelector(".profilesection");
    const staticimg = document.querySelector(".staticimg");
    const startquestion = document.querySelector(".startquestion");
    createpost.style.display = "block";
    line2.style.display = "block";
    Boxtwo.style.display = "block";
    Boxtwo.style.display = "flex";
    boxtwo.style.display = "none";
    box9.style.opacity = 0;
    box10.style.opacity = 1;
    box12.style.display = "none";
    profilesection.style.display = "block";
    staticimg.style.display = "block";
    startquestion.style.display = "none";
    text3.style.display = "block";
    text3.style.display = "flex";
    box6.onmouseover = () => {
      box6.style.backgroundColor = "rgb(247, 247, 247)";
    };
    box6.onmouseout = () => {
      box6.style.backgroundColor = "";
    };
    box7.onmouseover = () => {
      box7.style.backgroundColor = "white";
    };
    box7.onmouseout = () => {
      box7.style.backgroundColor = "white";
    };
  };
  const bold = () => {
    const Enable = document.querySelector("#Enable");
    Enable.addEventListener("focus", () => {
      Enable.style.fontWeight = "bold";
    });
  };
  const italic = () => {
    const Enable = document.querySelector("#Enable");
    Enable.addEventListener("focus", () => {
      Enable.style.fontStyle = "italic";
    });
  };