function share(){
  const sharediv=document.querySelector('.sharediv');
  const sharediv2=document.querySelector('.sharediv2');
  const sharediv3=document.querySelector('.sharediv3');
  const maincontainer = document.querySelector(".main_container");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestion = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  sharediv.style.display="none";
  sharediv2.style.display="none";
  sharediv3.style.display="none";
  postcontainer.style.top="";
  askquestion.style.position="";
  askquestion.style.filter="";
  styleeffect.style.backgroundColor = "";
  postsection1.style.filter = "";
  postsection2.style.filter = "";
  postsection3.style.filter = "";
  postsection4.style.filter = "";
  Nav.style.filter = "";
  maincontainer.style.filter = "";
}
function share4(){
  const sharediv4=document.querySelector('.sharediv4');
  const maincontainer = document.querySelector(".main_container");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestion = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  sharediv4.style.display="none";
  postcontainer.style.top="";
  askquestion.style.position="";
  askquestion.style.filter="";
  styleeffect.style.backgroundColor = "";
  postsection1.style.filter = "";
  postsection2.style.filter = "";
  postsection3.style.filter = "";
  postsection4.style.filter = "";
  Nav.style.filter = "";
  maincontainer.style.filter = "";
}
// Create a unique tooltip element
document.addEventListener('DOMContentLoaded',()=>{
  const tooltipdiv7 = document.createElement("div");
  tooltipdiv7.className = "tooltip8";
  document.body.appendChild(tooltipdiv7);
});
// Show tooltip
const tooltipdiv7 = document.createElement("div");
function showTooltip7(event) {
  const text7 = event.target.getAttribute("data-tooltip");
  if (text7) {
    tooltipdiv7.textContent = text7;
    tooltipdiv7.classList.add("show8");
  }
}

// Move tooltip along with the cursor
function moveTooltip7(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltipdiv7.style.left = `${event.pageX + tooltipOffset}px`;
  tooltipdiv7.style.top = `${event.pageY + tooltipOffset}px`;
}

// Hide tooltip
function hideTooltip7() {
  tooltipdiv7.classList.remove("show8");
}
// Create a unique tooltip element
document.addEventListener('DOMContentLoaded',()=>{
  const tooltipdiv4 = document.createElement("div");
  tooltipdiv4.className = "tooltip5";
  document.body.appendChild(tooltipdiv4);
});
// Create a unique tooltip element
const tooltipdiv4 = document.createElement("div");
const tooltipdiv5 = document.createElement("div");
tooltipdiv5.className = "tooltip6";
document.body.appendChild(tooltipdiv5);

// Show tooltip
function showTooltip4(event) {
  const text6 = event.target.getAttribute("data-tooltip");
  if (text6) {
    tooltipdiv5.textContent = text6;
    tooltipdiv5.classList.add("show6");
  }
}

// Move tooltip along with the cursor
function moveTooltip4(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltipdiv5.style.left = `${event.pageX + tooltipOffset}px`;
  tooltipdiv5.style.top = `${event.pageY + tooltipOffset}px`;
}

// Hide tooltip
function hideTooltip4() {
  tooltipdiv5.classList.remove("show6");
}

// Create a unique tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltipdivfive = document.createElement("div");
tooltipdivfive.className = "tooltip7";
document.body.appendChild(tooltipdivfive);
});

// Show tooltip
const tooltipdivfive = document.createElement("div");
function showTooltip5(event) {
  const textfive = event.target.getAttribute("data-tooltip");
  if (textfive) {
    tooltipdivfive.textContent = textfive;
    tooltipdivfive.classList.add("show7");
  }
}

// Move tooltip along with the cursor
function moveTooltip5(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltipdivfive.style.left = `${event.pageX + tooltipOffset}px`;
  tooltipdivfive.style.top = `${event.pageY + tooltipOffset}px`;
}

// Hide tooltip
function hideTooltip5() {
  tooltipdivfive.classList.remove("show7");
}

const fun1 = () => {
  const Flw = document.querySelector(".Flw");
  const Folw = document.querySelector(".Folw");
  Flw.style.display = "none";
  Folw.style.display = "block";
  Folw.style.display = "list-item";
};
const fun2 = () => {
  const Flw = document.querySelector(".Flw");
  const Folw = document.querySelector(".Folw");
  Flw.style.display = "block";
  Folw.style.display = "none";
  Flw.style.display = "list-item";
};
const fun3 = () => {
  const Flw2 = document.querySelector(".Flw2");
  const Folw2 = document.querySelector(".Folw2");
  Flw2.style.display = "none";
  Folw2.style.display = "block";
  Folw2.style.display = "list-item";
};
const fun4 = () => {
  const Flw2 = document.querySelector(".Flw2");
  const Folw2 = document.querySelector(".Folw2");
  Flw2.style.display = "block";
  Folw2.style.display = "none";
  Flw2.style.display = "list-item";
};
const fun5 = () => {
  const Flw3 = document.querySelector(".Flw3");
  const Folw3 = document.querySelector(".Folw3");
  Flw3.style.display = "none";
  Folw3.style.display = "block";
  Folw3.style.display = "list-item";
};
const fun6 = () => {
  const Flw3 = document.querySelector(".Flw3");
  const Folw3 = document.querySelector(".Folw3");
  Flw3.style.display = "block";
  Folw3.style.display = "none";
  Flw3.style.display = "list-item";
};
const fun7 = () => {
  const Flw4 = document.querySelector(".Flw4");
  const Folw4 = document.querySelector(".Folw4");
  Flw4.style.display = "none";
  Folw4.style.display = "block";
  Folw4.style.display = "list-item";
};
const fun8 = () => {
  const Flw4 = document.querySelector(".Flw4");
  const Folw4 = document.querySelector(".Folw4");
  Flw4.style.display = "block";
  Folw4.style.display = "none";
  Flw4.style.display = "list-item";
};
const hide1 = () => {
  const postsection1 = document.querySelector(".postsection1");
  postsection1.style.display = "none";
};
const hide2 = () => {
  const postsection2 = document.querySelector(".postsection2");
  postsection2.style.display = "none";
};
const hide3 = () => {
  const postsection3 = document.querySelector(".postsection3");
  postsection3.style.display = "none";
};
const hide4 = () => {
  const postsection4 = document.querySelector(".postsection4");
  postsection4.style.display = "none";
};
const upvote = () => {
  // Get the SVG path element
  const upvoteButton = document.querySelector(".upvote_button");
  const upvoteButton2 = document.querySelector(".upvote_button2");
  const upvoteButton3 = document.querySelector(".upvote_button3");
  const upvoteButton4 = document.querySelector(".upvote_button4");
  const upvote = document.querySelector(".upvote");
  const upvote2 = document.querySelector(".upvote2");
  const upvote3 = document.querySelector(".upvote3");
  const upvote4 = document.querySelector(".upvote4");
  const likecounter = document.querySelector(".likecounter");
  const likecounter2 = document.querySelector(".likecounter2");
  const likecounter3 = document.querySelector(".likecounter3");
  const likecounter4 = document.querySelector(".likecounter4");

  // Get the current fill attribute
  const currentFill = upvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    upvoteButton.setAttribute("fill", "blue");
    upvoteButton2.setAttribute("fill", "blue");
    upvoteButton3.setAttribute("fill", "blue");
    upvoteButton4.setAttribute("fill", "blue");
    upvote.style.color = "blue";
    upvote2.style.color = "blue";
    upvote3.style.color = "blue";
    upvote4.style.color = "blue";
    likecounter.style.color = "blue";
    likecounter2.style.color = "blue";
    likecounter3.style.color = "blue";
    likecounter4.style.color = "blue";
  } else {
    upvoteButton.setAttribute("fill", "none");
    upvoteButton2.setAttribute("fill", "none");
    upvoteButton3.setAttribute("fill", "none");
    upvoteButton4.setAttribute("fill", "none");
    upvote.style.color = "gray";
    upvote2.style.color = "gray";
    upvote3.style.color = "gray";
    upvote4.style.color = "gray";
    likecounter.style.color = "gray";
    likecounter2.style.color = "gray";
    likecounter3.style.color = "gray";
    likecounter4.style.color = "gray";
  }
};
const downvote1 = () => {
  // Get the SVG path element
  const downvoteButton = document.querySelector(".downvote_button");
  // Get the current fill attribute
  const currentFill = downvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    downvoteButton.setAttribute("fill", "rgb(203, 75, 16)");
  } else {
    downvoteButton.setAttribute("fill", "none");
  }
};

const downvote2 = () => {
  // Get the SVG path element
  const downvoteButton = document.querySelector(".downvote_button2");
  // Get the current fill attribute
  const currentFill = downvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    downvoteButton.setAttribute("fill", "rgb(203, 75, 16)");
  } else {
    downvoteButton.setAttribute("fill", "none");
  }
};

const downvote3 = () => {
  // Get the SVG path element
  const downvoteButton = document.querySelector(".downvote_button3");
  // Get the current fill attribute
  const currentFill = downvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    downvoteButton.setAttribute("fill", "rgb(203, 75, 16)");
  } else {
    downvoteButton.setAttribute("fill", "none");
  }
};
const downvote4 = () => {
  // Get the SVG path element
  const downvoteButton = document.querySelector(".downvote_button4");
  // Get the current fill attribute
  const currentFill = downvoteButton.getAttribute("fill");

  // Toggle between blue and none
  if (currentFill === "none") {
    downvoteButton.setAttribute("fill", "rgb(203, 75, 16)");
  } else {
    downvoteButton.setAttribute("fill", "none");
  }
};
const msgbox1 = () => {
  const addcomments = document.querySelector(".addcomments");
  const postsection1 = document.querySelector(".postsection1");
  const currentDisplay = getComputedStyle(addcomments).display;
  if (currentDisplay == "none") {
    addcomments.style.display = "block";
    postsection1.style.height = "89rem";
  } else {
    addcomments.style.display = "none";
    postsection1.style.height = "49rem";
  }
};
const msgbox2 = () => {
  const addcomments2 = document.querySelector(".addcomments2");
  const postsection2 = document.querySelector(".postsection2");
  // Get the computed display style
  const currentDisplay = getComputedStyle(addcomments2).display;
  if (currentDisplay == "none") {
    addcomments2.style.display = "block";
    postsection2.style.height = "98rem";
  } else {
    addcomments2.style.display = "none";
    postsection2.style.height = "49rem";
  }
};

const msgbox3 = () => {
  const addcomments3 = document.querySelector(".addcomments3");
  const postsection3 = document.querySelector(".postsection3");
  // Get the computed display style
  const currentDisplay = getComputedStyle(addcomments3).display;
  if (currentDisplay == "none") {
    addcomments3.style.display = "block";
    postsection3.style.height = "98rem";
  } else {
    addcomments3.style.display = "none";
    postsection3.style.height = "49rem";
  }
};

const msgbox4 = () => {
  const addcomments4 = document.querySelector(".addcomments4");
  const postsection4 = document.querySelector(".postsection4");
  // Get the computed display style
  const currentDisplay = getComputedStyle(addcomments4).display;
  if (currentDisplay == "none") {
    addcomments4.style.display = "block";
    postsection4.style.height = "93rem";
  } else {
    addcomments4.style.display = "none";
    postsection4.style.height = "49rem";
  }
};

const commentadded = () => {
  const inputtext = document.querySelector(".inputtext");
  const date = document.querySelector(".date");
  const authname = document.querySelector("#authname");
  const authorimg = document.querySelector("#authorimg");

  // Set current user and date
  date.style.display = "block";
  date.innerText = new Date().toLocaleDateString();
  authorimg.style.display = "block";
  authname.innerText = "You";

  // Add comment text
  const listdata = document.createElement("li");
  listdata.style.display = "flex";
  listdata.setAttribute("class", "data");
  listdata.innerText = inputtext.value;
  inputtext.value = "";

  const commentsdata = document.querySelector(".commentsdata");
  commentsdata.appendChild(listdata);
  // Add SVG (three dots icon)
  const svgNamespace = "http://www.w3.org/2000/svg";
  const svgtag = document.createElementNS(svgNamespace, "svg");
  svgtag.setAttribute("data-bs-toggle", "dropdown"); // Bootstrap toggle
  svgtag.setAttribute("aria-expanded", "false");
  svgtag.setAttribute("width", "24");
  svgtag.setAttribute("height", "24");
  svgtag.setAttribute("viewBox", "0 0 24 24");
  svgtag.setAttribute("fill", "none");
  svgtag.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  svgtag.style.cursor = "pointer";

  const path = document.createElementNS(svgNamespace, "path");
  path.setAttribute(
    "d",
    "M11.25 11.25a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm-7 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm14 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Z"
  );
  path.setAttribute("fill", "#666");
  path.setAttribute("stroke", "#666");
  path.setAttribute("stroke-width", "1.5");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svgtag.appendChild(path);

  // Add dropdown menu
  const dropdownMenu = document.createElement("ul");
  dropdownMenu.classList.add("dropdown-menu");
  dropdownMenu.style.position = "absolute"; // Ensure proper positioning

  // Edit button

  const editItem = document.createElement("li");
  const editLink = document.createElement("a");
  editLink.classList.add("dropdown-item");
  editLink.style.cursor = "pointer";
  editLink.innerText = "Edit";
  editLink.onclick = () => {
    listdata.remove();
    listdata.appendChild(wrapperDiv);
    commentsdata.appendChild(listdata);
    // create input tag
    const inputtag = document.createElement("input");
    inputtag.setAttribute("type", "text");
    inputtag.setAttribute("class", "editcomment");
    commentsdata.appendChild(inputtag);

    //create buttons

    const buttondiv = document.createElement("div");
    const Cancelbtn = document.createElement("button");
    const Updatebtn = document.createElement("button");
    Cancelbtn.setAttribute("class", "btn");
    Cancelbtn.style.height = "2.5rem";
    Cancelbtn.innerText = "Cancel";
    Updatebtn.setAttribute("class", "btn btn-primary");
    Updatebtn.style.height = "2.5rem";
    Updatebtn.innerText = "Update";
    buttondiv.style.marginTop = "2.6rem";
    buttondiv.appendChild(Cancelbtn);
    buttondiv.appendChild(Updatebtn);
    commentsdata.appendChild(buttondiv);

    // Update text
    Updatebtn.onclick = () => {
      const editcomment = document.querySelector(".editcomment");
      const edittext = editcomment.value;
      const promptvalue = prompt("Are you sure?");

      if (editcomment) editcomment.remove();
      if (buttondiv) buttondiv.remove();

      if (promptvalue && promptvalue.trim().toLowerCase() === "yes") {
        // User confirmed with "yes"
        listdata.innerText = edittext; // Update the comment text
        listdata.appendChild(wrapperDiv); // Reattach the dropdown and SVG
        console.log("Changes saved.");

        // Hide the input box and button div
        editcomment.style.display = "none";
        buttondiv.style.display = "none";
      }
    };
    // cancel text
    Cancelbtn.onclick = () => {
      const editcomment = document.querySelector(".editcomment");
      if (editcomment) editcomment.remove();
      if (buttondiv) buttondiv.remove();

      editcomment.style.display = "none";
      buttondiv.style.display = "none";
    };
  };
  editItem.appendChild(editLink);
  dropdownMenu.appendChild(editItem);

  // Delete button
  const deleteItem = document.createElement("li");
  const deleteLink = document.createElement("a");
  deleteLink.classList.add("dropdown-item");
  deleteLink.style.cursor = "pointer";
  deleteLink.innerText = "Delete";
  deleteLink.onclick = () => {
    listdata.remove(); // Remove the comment
    dropdownMenu.remove(); // Remove the dropdown
    svgtag.remove();
  };
  deleteItem.appendChild(deleteLink);
  dropdownMenu.appendChild(deleteItem);

  // Attach the dropdown to the SVG
  const wrapperDiv = document.createElement("div");
  wrapperDiv.style.position = "relative";
  wrapperDiv.appendChild(dropdownMenu);
  wrapperDiv.appendChild(svgtag);
  listdata.appendChild(wrapperDiv);
};

const commentadded2 = () => {
  const inputtext = document.querySelector(".inputtext2");
  const date = document.querySelector(".date2");
  const authname = document.querySelector("#authname2");
  const authorimg = document.querySelector("#authorimg2");

  // Set current user and date
  date.style.display = "block";
  date.innerText = new Date().toLocaleDateString();
  authorimg.style.display = "block";
  authname.innerText = "You";

  // Add comment text
  const listdata = document.createElement("li");
  listdata.style.display = "flex";
  listdata.setAttribute("class", "data");
  listdata.innerText = inputtext.value;
  inputtext.value = "";

  const commentsdata2 = document.querySelector(".commentsdata2");
  commentsdata2.appendChild(listdata);
  // Add SVG (three dots icon)
  const svgNamespace = "http://www.w3.org/2000/svg";
  const svgtag = document.createElementNS(svgNamespace, "svg");
  svgtag.setAttribute("data-bs-toggle", "dropdown"); // Bootstrap toggle
  svgtag.setAttribute("aria-expanded", "false");
  svgtag.setAttribute("width", "24");
  svgtag.setAttribute("height", "24");
  svgtag.setAttribute("viewBox", "0 0 24 24");
  svgtag.setAttribute("fill", "none");
  svgtag.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  svgtag.style.cursor = "pointer";

  const path = document.createElementNS(svgNamespace, "path");
  path.setAttribute(
    "d",
    "M11.25 11.25a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm-7 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm14 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Z"
  );
  path.setAttribute("fill", "#666");
  path.setAttribute("stroke", "#666");
  path.setAttribute("stroke-width", "1.5");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svgtag.appendChild(path);

  // Add dropdown menu
  const dropdownMenu = document.createElement("ul");
  dropdownMenu.classList.add("dropdown-menu");
  dropdownMenu.style.position = "absolute"; // Ensure proper positioning

  // Edit button

  const editItem = document.createElement("li");
  const editLink = document.createElement("a");
  editItem.style.listStyleType = "none";
  editLink.classList.add("dropdown-item");
  editLink.style.cursor = "pointer";
  editLink.innerText = "Edit";
  editLink.onclick = () => {
    listdata.remove();
    listdata.appendChild(wrapperDiv);
    commentsdata2.appendChild(listdata);
    // create input tag
    const inputtag = document.createElement("input");
    inputtag.setAttribute("type", "text");
    inputtag.setAttribute("class", "editcomment2");
    commentsdata2.appendChild(inputtag);

    //create buttons

    const buttondiv = document.createElement("div");
    const Cancelbtn = document.createElement("button");
    const Updatebtn = document.createElement("button");
    Cancelbtn.setAttribute("class", "btn");
    Cancelbtn.style.height = "2.5rem";
    Cancelbtn.innerText = "Cancel";
    Updatebtn.setAttribute("class", "btn btn-primary");
    Updatebtn.style.height = "2.5rem";
    Updatebtn.innerText = "Update";
    buttondiv.style.marginTop = "2.6rem";
    buttondiv.appendChild(Cancelbtn);
    buttondiv.appendChild(Updatebtn);
    commentsdata2.appendChild(buttondiv);

    // Update text
    Updatebtn.onclick = () => {
      const editcomment2 = document.querySelector(".editcomment2");
      const edittext = editcomment2.value;
      const promptvalue = prompt("Are you sure?");

      if (editcomment2) editcomment2.remove();
      if (buttondiv) buttondiv.remove();

      if (promptvalue && promptvalue.trim().toLowerCase() === "yes") {
        // User confirmed with "yes"
        listdata.innerText = edittext; // Update the comment text
        listdata.appendChild(wrapperDiv); // Reattach the dropdown and SVG
        console.log("Changes saved.");

        // Hide the input box and button div
        editcomment2.style.display = "none";
        buttondiv.style.display = "none";
      }
    };
    // cancel text
    Cancelbtn.onclick = () => {
      const editcomment2 = document.querySelector(".editcomment2");
      if (editcomment2) editcomment2.remove();
      if (buttondiv) buttondiv.remove();

      editcomment2.style.display = "none";
      buttondiv.style.display = "none";
    };
  };
  editItem.appendChild(editLink);
  dropdownMenu.appendChild(editItem);

  // Delete button
  const deleteItem = document.createElement("li");
  const deleteLink = document.createElement("a");
  deleteLink.classList.add("dropdown-item");
  deleteLink.style.cursor = "pointer";
  deleteLink.innerText = "Delete";
  deleteLink.onclick = () => {
    listdata.remove(); // Remove the comment
    dropdownMenu.remove(); // Remove the dropdown
    svgtag.remove();
  };
  deleteItem.appendChild(deleteLink);
  dropdownMenu.appendChild(deleteItem);

  // Attach the dropdown to the SVG
  const wrapperDiv = document.createElement("div");
  wrapperDiv.style.position = "relative";
  wrapperDiv.appendChild(dropdownMenu);
  wrapperDiv.appendChild(svgtag);
  listdata.appendChild(wrapperDiv);
};

const commentadded3 = () => {
  const inputtext = document.querySelector(".inputtext3");
  const date = document.querySelector(".date3");
  const authname = document.querySelector("#authname3");
  const authorimg = document.querySelector("#authorimg3");

  // Set current user and date
  date.style.display = "block";
  date.innerText = new Date().toLocaleDateString();
  authorimg.style.display = "block";
  authname.innerText = "You";

  // Add comment text
  const listdata = document.createElement("li");
  listdata.style.display = "flex";
  listdata.setAttribute("class", "data");
  listdata.innerText = inputtext.value;
  inputtext.value = "";

  const commentsdata3 = document.querySelector(".commentsdata3");
  commentsdata3.appendChild(listdata);
  // Add SVG (three dots icon)
  const svgNamespace = "http://www.w3.org/2000/svg";
  const svgtag = document.createElementNS(svgNamespace, "svg");
  svgtag.setAttribute("data-bs-toggle", "dropdown"); // Bootstrap toggle
  svgtag.setAttribute("aria-expanded", "false");
  svgtag.setAttribute("width", "24");
  svgtag.setAttribute("height", "24");
  svgtag.setAttribute("viewBox", "0 0 24 24");
  svgtag.setAttribute("fill", "none");
  svgtag.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  svgtag.style.cursor = "pointer";

  const path = document.createElementNS(svgNamespace, "path");
  path.setAttribute(
    "d",
    "M11.25 11.25a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm-7 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm14 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Z"
  );
  path.setAttribute("fill", "#666");
  path.setAttribute("stroke", "#666");
  path.setAttribute("stroke-width", "1.5");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svgtag.appendChild(path);

  // Add dropdown menu
  const dropdownMenu = document.createElement("ul");
  dropdownMenu.classList.add("dropdown-menu");
  dropdownMenu.style.position = "absolute"; // Ensure proper positioning

  // Edit button

  const editItem = document.createElement("li");
  const editLink = document.createElement("a");
  editItem.style.listStyleType = "none";
  editLink.classList.add("dropdown-item");
  editLink.style.cursor = "pointer";
  editLink.innerText = "Edit";
  editLink.onclick = () => {
    listdata.remove();
    listdata.appendChild(wrapperDiv);
    commentsdata3.appendChild(listdata);
    // create input tag
    const inputtag = document.createElement("input");
    inputtag.setAttribute("type", "text");
    inputtag.setAttribute("class", "editcomment3");
    commentsdata3.appendChild(inputtag);

    //create buttons

    const buttondiv = document.createElement("div");
    const Cancelbtn = document.createElement("button");
    const Updatebtn = document.createElement("button");
    Cancelbtn.setAttribute("class", "btn");
    Cancelbtn.style.height = "2.5rem";
    Cancelbtn.innerText = "Cancel";
    Updatebtn.setAttribute("class", "btn btn-primary");
    Updatebtn.style.height = "2.5rem";
    Updatebtn.innerText = "Update";
    buttondiv.style.marginTop = "2.6rem";
    buttondiv.appendChild(Cancelbtn);
    buttondiv.appendChild(Updatebtn);
    commentsdata3.appendChild(buttondiv);

    // Update text
    Updatebtn.onclick = () => {
      const editcomment3 = document.querySelector(".editcomment3");
      const edittext = editcomment3.value;
      const promptvalue = prompt("Are you sure?");

      if (editcomment3) editcomment3.remove();
      if (buttondiv) buttondiv.remove();

      if (promptvalue && promptvalue.trim().toLowerCase() === "yes") {
        // User confirmed with "yes"
        listdata.innerText = edittext; // Update the comment text
        listdata.appendChild(wrapperDiv); // Reattach the dropdown and SVG
        console.log("Changes saved.");

        // Hide the input box and button div
        editcomment3.style.display = "none";
        buttondiv.style.display = "none";
      }
    };
    // cancel text
    Cancelbtn.onclick = () => {
      const editcomment3 = document.querySelector(".editcomment3");
      if (editcomment3) editcomment3.remove();
      if (buttondiv) buttondiv.remove();

      editcomment3.style.display = "none";
      buttondiv.style.display = "none";
    };
  };
  editItem.appendChild(editLink);
  dropdownMenu.appendChild(editItem);

  // Delete button
  const deleteItem = document.createElement("li");
  const deleteLink = document.createElement("a");
  deleteLink.classList.add("dropdown-item");
  deleteLink.style.cursor = "pointer";
  deleteLink.innerText = "Delete";
  deleteLink.onclick = () => {
    listdata.remove(); // Remove the comment
    dropdownMenu.remove(); // Remove the dropdown
    svgtag.remove();
  };
  deleteItem.appendChild(deleteLink);
  dropdownMenu.appendChild(deleteItem);

  // Attach the dropdown to the SVG
  const wrapperDiv = document.createElement("div");
  wrapperDiv.style.position = "relative";
  wrapperDiv.appendChild(dropdownMenu);
  wrapperDiv.appendChild(svgtag);
  listdata.appendChild(wrapperDiv);
};

const commentadded4 = () => {
  const inputtext = document.querySelector(".inputtext4");
  const date = document.querySelector(".date4");
  const authname = document.querySelector("#authname4");
  const authorimg = document.querySelector("#authorimg4");

  // Set current user and date
  date.style.display = "block";
  date.innerText = new Date().toLocaleDateString();
  authorimg.style.display = "block";
  authname.innerText = "You";

  // Add comment text
  const listdata = document.createElement("li");
  listdata.style.display = "flex";
  listdata.setAttribute("class", "data");
  listdata.innerText = inputtext.value;
  inputtext.value = "";

  const commentsdata4 = document.querySelector(".commentsdata4");
  commentsdata4.appendChild(listdata);
  // Add SVG (three dots icon)
  const svgNamespace = "http://www.w3.org/2000/svg";
  const svgtag = document.createElementNS(svgNamespace, "svg");
  svgtag.setAttribute("data-bs-toggle", "dropdown"); // Bootstrap toggle
  svgtag.setAttribute("aria-expanded", "false");
  svgtag.setAttribute("width", "24");
  svgtag.setAttribute("height", "24");
  svgtag.setAttribute("viewBox", "0 0 24 24");
  svgtag.setAttribute("fill", "none");
  svgtag.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  svgtag.style.cursor = "pointer";

  const path = document.createElementNS(svgNamespace, "path");
  path.setAttribute(
    "d",
    "M11.25 11.25a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm-7 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Zm14 0a1.06 1.06 0 1 0 1.5 1.5 1.06 1.06 0 0 0-1.5-1.5Z"
  );
  path.setAttribute("fill", "#666");
  path.setAttribute("stroke", "#666");
  path.setAttribute("stroke-width", "1.5");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svgtag.appendChild(path);

  // Add dropdown menu
  const dropdownMenu = document.createElement("ul");
  dropdownMenu.classList.add("dropdown-menu");
  dropdownMenu.style.position = "absolute"; // Ensure proper positioning

  // Edit button

  const editItem = document.createElement("li");
  const editLink = document.createElement("a");
  editItem.style.listStyleType = "none";
  editLink.classList.add("dropdown-item");
  editLink.style.cursor = "pointer";
  editLink.innerText = "Edit";
  editLink.onclick = () => {
    listdata.remove();
    listdata.appendChild(wrapperDiv);
    commentsdata4.appendChild(listdata);
    // create input tag
    const inputtag = document.createElement("input");
    inputtag.setAttribute("type", "text");
    inputtag.setAttribute("class", "editcomment4");
    commentsdata4.appendChild(inputtag);

    //create buttons

    const buttondiv = document.createElement("div");
    const Cancelbtn = document.createElement("button");
    const Updatebtn = document.createElement("button");
    Cancelbtn.setAttribute("class", "btn");
    Cancelbtn.style.height = "2.5rem";
    Cancelbtn.innerText = "Cancel";
    Updatebtn.setAttribute("class", "btn btn-primary");
    Updatebtn.style.height = "2.5rem";
    Updatebtn.innerText = "Update";
    buttondiv.style.marginTop = "2.6rem";
    buttondiv.appendChild(Cancelbtn);
    buttondiv.appendChild(Updatebtn);
    commentsdata4.appendChild(buttondiv);

    // Update text
    Updatebtn.onclick = () => {
      const editcomment4 = document.querySelector(".editcomment4");
      const edittext = editcomment4.value;
      const promptvalue = prompt("Are you sure?");

      if (editcomment4) editcomment4.remove();
      if (buttondiv) buttondiv.remove();

      if (promptvalue && promptvalue.trim().toLowerCase() === "yes") {
        // User confirmed with "yes"
        listdata.innerText = edittext; // Update the comment text
        listdata.appendChild(wrapperDiv); // Reattach the dropdown and SVG
        console.log("Changes saved.");

        // Hide the input box and button div
        editcomment4.style.display = "none";
        buttondiv.style.display = "none";
      }
    };
    // cancel text
    Cancelbtn.onclick = () => {
      const editcomment4 = document.querySelector(".editcomment4");
      if (editcomment4) editcomment4.remove();
      if (buttondiv) buttondiv.remove();

      editcomment4.style.display = "none";
      buttondiv.style.display = "none";
    };
  };
  editItem.appendChild(editLink);
  dropdownMenu.appendChild(editItem);

  // Delete button
  const deleteItem = document.createElement("li");
  const deleteLink = document.createElement("a");
  deleteLink.classList.add("dropdown-item");
  deleteLink.style.cursor = "pointer";
  deleteLink.innerText = "Delete";
  deleteLink.onclick = () => {
    listdata.remove(); // Remove the comment
    dropdownMenu.remove(); // Remove the dropdown
    svgtag.remove();
  };
  deleteItem.appendChild(deleteLink);
  dropdownMenu.appendChild(deleteItem);

  // Attach the dropdown to the SVG
  const wrapperDiv = document.createElement("div");
  wrapperDiv.style.position = "relative";
  wrapperDiv.appendChild(dropdownMenu);
  wrapperDiv.appendChild(svgtag);
  listdata.appendChild(wrapperDiv);
};

const sharenow1 = () => {
  const sharediv = document.querySelector(".sharediv");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const posteddate = document.querySelector("#posteddate");
  const maincontainer = document.querySelector(".main_container");
  const data = document.querySelector("#data");
  const imagename = document.querySelector("#imagename");
  const imgtext = document.querySelector(".imgtext");
  const Pdata = document.querySelector(".Pdata");
  const heading = document.querySelector("#heading");
  const data1 = document.querySelector(".data1");
  const data2 = document.querySelector(".data2");
  const postedtext = document.querySelector("#postedtext");

  sharediv.style.display = "block";
  postcontainer.style.top = "9rem";
  styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "brightness(0.5)";
  postsection2.style.filter = "brightness(0.5)";
  postsection3.style.filter = "brightness(0.5)";
  postsection4.style.filter = "brightness(0.5)";
  askquestions.style.filter = "brightness(0.5)";
  Nav.style.filter = "brightness(0.5)";
  maincontainer.style.filter = "brightness(0.5)";

  const image = document.createElement("img");
  image.style.borderRadius = "2rem";
  image.style.width = "1rem";
  data.innerHTML = "";
  image.src = "../../images/Wonder.png";
  image.alt = "Wonder";
  data.appendChild(image);
  imgtext.innerText = imagename.innerText;
  imgtext.style.fontWeight = "500";
  imgtext.style.fontSize = "0.7rem";
  imgtext.style.position = "absolute";
  imgtext.style.top = "0.5rem";
  imgtext.style.left = "1.3rem";
  imgtext.style.display = "flex";
  imgtext.style.color = "gray";

  const datelist = document.createElement("ul");
  const dated = document.createElement("li");
  datelist.style.color = "gray";
  datelist.appendChild(dated);

  // append data in list
  dated.innerText = posteddate.innerText;
  imgtext.appendChild(datelist);
  Pdata.innerText = heading.innerText;
  data1.style.position = "absolute";
  data1.style.left = "2%";
  data1.innerText = postedtext.innerText;

  const img = document.createElement("img");
  data2.innerHTML = "";
  img.src = "../../images/pic.png";
  data2.append(img);
};

const sharenow2 = () => {
  const sharediv2 = document.querySelector(".sharediv2");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const posteddate2 = document.querySelector("#posteddate2");
  const maincontainer = document.querySelector(".main_container");
  const Data2 = document.querySelector("#data2");
  const imagename2 = document.querySelector("#imagename2");
  const imgtext2 = document.querySelector(".imgtext2");
  const Pdata2 = document.querySelector(".Pdata2");
  const heading2 = document.querySelector("#heading2");
  const dataone = document.querySelector(".dataone");
  const datatwo = document.querySelector(".datatwo");
  const postedtext2 = document.querySelector("#postedtext2");

  sharediv2.style.display = "block";
  postcontainer.style.top = "6rem";
  styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "brightness(0.5)";
  postsection2.style.filter = "brightness(0.5)";
  postsection3.style.filter = "brightness(0.5)";
  postsection4.style.filter = "brightness(0.5)";
  askquestions.style.filter = "brightness(0.5)";
  Nav.style.filter = "brightness(0.5)";
  maincontainer.style.filter = "brightness(0.5)";

  const image = document.createElement("img");
  image.style.borderRadius = "2rem";
  image.style.width = "1rem";
  Data2.innerHTML = "";
  image.src = "../../images/Wonder.png";
  image.alt = "Wonder";
  Data2.appendChild(image);
  imgtext2.innerText = imagename2.innerText;
  imgtext2.style.fontWeight = "500";
  imgtext2.style.fontSize = "0.7rem";
  imgtext2.style.position = "absolute";
  imgtext2.style.top = "0.5rem";
  imgtext2.style.left = "1.3rem";
  imgtext2.style.display = "flex";
  imgtext2.style.color = "gray";

  const datelist = document.createElement("ul");
  const dated = document.createElement("li");
  datelist.style.color = "gray";
  datelist.appendChild(dated);

  // append data in list
  dated.innerText = posteddate2.innerText;
  imgtext2.appendChild(datelist);
  Pdata2.innerText = heading2.innerText;
  dataone.style.position = "absolute";
  dataone.style.left = "2%";
  dataone.innerText = postedtext2.innerText;

  const img = document.createElement("img");
  datatwo.innerHTML = "";
  img.src = "../../images/pic2.png";
  img.style.width = "37rem";
  img.style.height = "30rem";
  datatwo.append(img);
};
const sharenow3 = () => {
  const sharediv3 = document.querySelector(".sharediv3");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const posteddate3 = document.querySelector("#posteddate3");
  const maincontainer = document.querySelector(".main_container");
  const Data3 = document.querySelector("#data3");
  const imagename3 = document.querySelector("#imagename3");
  const imgtext3 = document.querySelector(".imgtext3");
  const Pdata3 = document.querySelector(".Pdata3");
  const heading3 = document.querySelector("#heading3");
  const datathree = document.querySelector(".datathree");
  const datafour = document.querySelector(".datafour");
  const postedtext3 = document.querySelector("#postedtext3");

  sharediv3.style.display = "block";
  postcontainer.style.top = "6rem";
  styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "brightness(0.5)";
  postsection2.style.filter = "brightness(0.5)";
  postsection3.style.filter = "brightness(0.5)";
  postsection4.style.filter = "brightness(0.5)";
  askquestions.style.filter = "brightness(0.5)";
  Nav.style.filter = "brightness(0.5)";
  maincontainer.style.filter = "brightness(0.5)";

  const image = document.createElement("img");
  image.style.borderRadius = "2rem";
  image.style.width = "1rem";
  Data3.innerHTML = "";
  image.src = "../../images/Raghav.png";
  image.alt = "Wonder";
  Data3.appendChild(image);
  imgtext3.innerText = imagename3.innerText;
  imgtext3.style.fontWeight = "500";
  imgtext3.style.fontSize = "0.7rem";
  imgtext3.style.position = "absolute";
  imgtext3.style.top = "0.5rem";
  imgtext3.style.left = "1.3rem";
  imgtext3.style.display = "flex";
  imgtext3.style.color = "gray";

  const datelist = document.createElement("ul");
  const dated = document.createElement("li");
  datelist.style.color = "gray";
  datelist.appendChild(dated);

  // append data in list
  dated.innerText = posteddate3.innerText;
  imgtext3.appendChild(datelist);
  Pdata3.innerText = heading3.innerText;
  datathree.style.position = "absolute";
  datathree.style.left = "2%";
  datathree.innerText = postedtext3.innerText;

  const img = document.createElement("img");
  datafour.innerHTML = "";
  img.src = "../../images/Raghavpic.png";
  img.style.width = "37rem";
  img.style.height = "30rem";
  datafour.append(img);
};

const sharenow4 = () => {
  const sharediv4 = document.querySelector(".sharediv4");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const posteddate4 = document.querySelector("#posteddate4");
  const maincontainer = document.querySelector(".main_container");
  const Data4 = document.querySelector("#data4");
  const imagename4 = document.querySelector("#imagename4");
  const imgtext4 = document.querySelector(".imgtext4");
  const Pdata4 = document.querySelector(".Pdata4");
  const heading4 = document.querySelector("#heading4");
  const datafive = document.querySelector(".datafive");
  const datasix = document.querySelector(".datasix");
  const postedtext4 = document.querySelector("#postedtext4");
  const BoxContainer = document.querySelector("#BoxContainer");

  sharediv4.style.display = "block";
  postcontainer.style.top = "6rem";
  styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "brightness(0.5)";
  postsection2.style.filter = "brightness(0.5)";
  postsection3.style.filter = "brightness(0.5)";
  postsection4.style.filter = "brightness(0.5)";
  askquestions.style.filter = "brightness(0.5)";
  Nav.style.filter = "brightness(0.5)";
  maincontainer.style.filter = "brightness(0.5)";
  BoxContainer.style.height="220rem";
  
  const image = document.createElement("img");
  image.style.borderRadius = "2rem";
  image.style.width = "1rem";
  Data4.innerHTML = "";
  image.src = "../../images/suresh.png";
  image.alt = "Wonder";
  Data4.appendChild(image);
  imgtext4.innerText = imagename4.innerText;
  imgtext4.style.fontWeight = "500";
  imgtext4.style.fontSize = "0.7rem";
  imgtext4.style.position = "absolute";
  imgtext4.style.top = "0.5rem";
  imgtext4.style.left = "1.3rem";
  imgtext4.style.display = "flex";
  imgtext4.style.color = "gray";

  const datelist = document.createElement("ul");
  const dated = document.createElement("li");
  datelist.style.color = "gray";
  datelist.appendChild(dated);

  // append data in list
  dated.innerText = posteddate4.innerText;
  imgtext4.appendChild(datelist);
  Pdata4.innerText = heading4.innerText;
  datafive.style.position = "absolute";
  datafive.style.left = "2%";
  datafive.innerText = postedtext4.innerText;

  const img = document.createElement("img");
  datasix.innerHTML = "";
  img.src = "../../images/krishna.png";
  img.style.width = "37rem";
  img.style.height = "30rem";
  datasix.style.position="absolute";  
  datasix.style.top="23rem"
  datasix.append(img);
};

const closesharediv = () => {
  const sharediv = document.querySelector(".sharediv");
  const sharediv2 = document.querySelector(".sharediv2");
  const sharediv3 = document.querySelector(".sharediv3");
  const sharediv4 = document.querySelector(".sharediv4");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const maincontainer = document.querySelector(".main_container");
  sharediv.style.display = "none";
  sharediv2.style.display = "none";
  sharediv3.style.display = "none";
  sharediv4.style.display = "none";
  postcontainer.style.top = "";
  styleeffect.style.backgroundColor = "";
  askquestions.style.position = "";
  postsection1.style.filter = "";
  postsection2.style.filter = "";
  postsection3.style.filter = "";
  postsection4.style.filter = "";
  askquestions.style.filter = "";
  Nav.style.filter = "";
  maincontainer.style.filter = "";
};

const opendialog = () => {
  const maincontainer = document.querySelector(".main_container");
  const questiondialogbox = document.querySelector(".questiondialogbox");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postcontainer = document.querySelector(".postcontainer");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  postcontainer.style.top = "2rem";
  questiondialogbox.style.display = "block";
  styleeffect.style.backgroundColor = "rgb(128, 128, 128)";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "brightness(0.5)";
  postsection2.style.filter = "brightness(0.5)";
  postsection3.style.filter = "brightness(0.5)";
  postsection4.style.filter = "brightness(0.5)";
  askquestions.style.filter = "brightness(0.5)";
  Nav.style.filter = "brightness(0.5)";
  maincontainer.style.filter = "brightness(0.5)";
};
const menu1 = () => {
  const img1 = document.querySelector("#img1");
  const img2 = document.querySelector("#img2");
  const change = document.querySelector("#change");
  const menu1 = document.querySelector(".menu1");
  img1.style.display = "block";
  img2.style.display = "none";
  change.innerText = menu1.innerText;
};
const menu2 = () => {
  const img1 = document.querySelector("#img1");
  const img2 = document.querySelector("#img2");
  const menu2 = document.querySelector(".menu2");
  const change = document.querySelector("#change");
  img1.style.display = "none";
  img2.style.display = "block";
  change.innerText = menu2.innerText;
};
const startnow = () => {
  const questionstart = document.querySelector("#questionstart");
  const after = document.querySelector("#after");
  questionstart.style.display = "none";
  after.style.display = "block";
};
const createpost = () => {
  const postdiv = document.querySelector("#postdiv");
  const Enable = document.querySelector("#Enable");
  postdiv.style.display = "none";
  Enable.style.display = "block";
};
const hovercolor = () => {
  const line = document.querySelector(".line");
  line.style.border = "1px solid blue";
};
const hoveroutcolor = () => {
  const line = document.querySelector(".line");
  line.style.border = "";
};
const exec = () => {
  const textarea = document.querySelector("#after");
  const line = document.querySelector(".line");
  const addquestion = document.querySelector("#addquestion");

  // Get the scroll height (amount of overflow) of the textarea
  const textHeight = textarea.scrollHeight;

  // Adjust the position of the <hr> based on the textarea's height
  // Add some spacing

  if (textarea.value.trim() === "") {
    addquestion.style.opacity = 0.4;
    line.style.top = "10%";
  } else {
    addquestion.style.cursor="pointer";
    addquestion.style.opacity = 1;
    line.style.top = `${textHeight + 0.2}px`;
  }
};
const exec2 = () => {
  const textarea = document.querySelector("#Enable");
  const postbtn = document.querySelector("#postbtn");

  if (textarea.value.trim() === "") {
    postbtn.style.opacity = 0.4;
    postbtn.style.cursor = "default";
  } else {
    postbtn.style.opacity = 1;
    postbtn.style.cursor = "pointer";
  }
};
const questionbox = () => {
  const createpost = document.querySelector(".createpost");
  const line2 = document.querySelector(".line2");
  const box6 = document.querySelector(".box6");
  const box9 = document.querySelector(".box9");
  const box10 = document.querySelector(".box10");
  const box11 = document.querySelector(".box11");
  const text3 = document.querySelector(".text3");
  const box12 = document.querySelector(".box12");
  const startquestion = document.querySelector(".startquestion");
  const Boxtwo = document.querySelector(".Boxtwo");
  const boxtwo = document.querySelector(".boxtwo");
  createpost.style.display = "none";
  box9.style.opacity = 1;
  box10.style.opacity = 0;
  line2.style.display = "none";
  box11.style.display = "block";
  box12.style.display = "block";
  box12.style.display = "flex";
  text3.style.display = "none";
  Boxtwo.style.display = "none";
  boxtwo.style.display = "block";
  boxtwo.style.display = "flex";
  startquestion.style.display = "block";
  box6.onmouseover = () => {
    box6.style.backgroundColor = "white";
  };
  box6.onmouseout = () => {
    box6.style.backgroundColor = "white";
  };
};
const postdiv = () => {
  const line2 = document.querySelector(".line2");
  const box6 = document.querySelector(".box6");
  const box7 = document.querySelector(".box7");
  const box9 = document.querySelector(".box9");
  const box10 = document.querySelector(".box10");
  const box12 = document.querySelector(".box12");
  const createpost = document.querySelector(".createpost");
  const text3 = document.querySelector(".text3");
  const boxtwo = document.querySelector(".boxtwo");
  const Boxtwo = document.querySelector(".Boxtwo");
  const profilesection = document.querySelector(".profilesection");
  const staticimg = document.querySelector(".staticimg");
  const startquestion = document.querySelector(".startquestion");
  createpost.style.display = "block";
  line2.style.display = "block";
  Boxtwo.style.display = "block";
  Boxtwo.style.display = "flex";
  boxtwo.style.display = "none";
  box9.style.opacity = 0;
  box10.style.opacity = 1;
  box12.style.display = "none";
  profilesection.style.display = "block";
  staticimg.style.display = "block";
  startquestion.style.display = "none";
  text3.style.display = "block";
  text3.style.display = "flex";
  box6.onmouseover = () => {
    box6.style.backgroundColor = "rgb(247, 247, 247)";
  };
  box6.onmouseout = () => {
    box6.style.backgroundColor = "";
  };
  box7.onmouseover = () => {
    box7.style.backgroundColor = "white";
  };
  box7.onmouseout = () => {
    box7.style.backgroundColor = "white";
  };
};
const close1 = () => {
  const maincontainer = document.querySelector(".main_container");
  const questiondialogbox = document.querySelector(".questiondialogbox");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  questiondialogbox.style.display = "none";
  styleeffect.style.backgroundColor = "";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "";
  postsection2.style.filter = "";
  postsection3.style.filter = "";
  postsection4.style.filter = "";
  askquestions.style.filter = "";
  Nav.style.filter = "";
  maincontainer.style.filter = "";
};
const add = () => {
  const textarea = document.querySelector("#after");
  const addedQ = document.querySelector(".addedQ");
  const newdiv=document.createElement('div');
  const addnow = document.querySelector(".addnow");
  const postcontainer = document.querySelector(".postcontainer");
  const expanddiv = document.querySelector(".ask_questions");
  const container1 = document.querySelector(".container1");
  const container3 = document.querySelector(".container3");
  const maincontainer = document.querySelector(".main_container");
  const questiondialogbox = document.querySelector(".questiondialogbox");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  const parent = document.querySelector(".parent");
  addedQ.style.display = "block";
  newdiv.innerText= textarea.value.trim();
  addnow.appendChild(newdiv);
  addnow.style.fontWeight = "500";
  container1.style.top = "10%";
  container3.style.top = "30%";
  postcontainer.style.top = "22rem";
  expanddiv.style.height = "20rem";
  parent.style.overflowY = "scroll";
  questiondialogbox.style.display = "none";
  styleeffect.style.backgroundColor = "";
  askquestions.style.position = "absolute";
  postsection1.style.filter = "";
  postsection2.style.filter = "";
  postsection3.style.filter = "";
  postsection4.style.filter = "";
  askquestions.style.filter = "";
  Nav.style.filter = "";
  maincontainer.style.filter = "";
};
const senddata = () => {
  const getdata = document.querySelector("#Enable").value;
  const imageElements = document.querySelectorAll(".imagesection img");

  const formData = new FormData();
  formData.append("getdata", getdata);

  let imagePromises = [];

  imageElements.forEach((imageElement, index) => {
    imagePromises.push(
      fetch(imageElement.src)
        .then((response) => response.blob())
        .then((blob) => {
          const file = new File([blob], `uploaded_image_${index}.jpg`, {
            type: blob.type,
          });
          formData.append("images", file);
        })
    );
  });

  Promise.all(imagePromises)
    .then(() => {
      return fetch("/postdata", {
        method: "POST",
        body: formData,
      });
    })
    .then((response) => {
      if (response.redirected) {
        window.location.href = response.url;
      }
    })
    .catch((err) => console.error("Error:", err));
};
const AddQuestion = document.querySelector("#Add_Question");
AddQuestion.addEventListener("click", () => {
  opendialog();
});
const showstyles = () => {
  const shownow = document.querySelector(".shownow");
  const photosvg = document.querySelector("#photosvg");
  const fontstylessvg = document.querySelector("#fontstylessvg");
  shownow.style.display = "block";
  shownow.style.display = "flex";
  photosvg.style.display = "none";
  fontstylessvg.style.display = "none";
};
const togglefnc = () => {
  const dropdowntogglebtn = document.querySelector(".dropdowntogglebtn");
  const shownow = document.querySelector(".shownow");
  const photosvg = document.querySelector("#photosvg");
  const fontstylessvg = document.querySelector("#fontstylessvg");
  if (dropdowntogglebtn.style.display == "none") {
    shownow.style.display = "block";
    photosvg.style.display = "none";
    fontstylessvg.style.display = "none";
  } else {
    shownow.style.display = "none";
    photosvg.style.display = "block";
    fontstylessvg.style.display = "block";
  }
};
const hidenow = () => {
  const editpost = document.querySelector(".editpost");
  const bgcolor = document.querySelector(".bgcolor");
  const postedsection = document.querySelector(".postedsection");
  const likecontainer2 = document.querySelector(".likecontainer2");
  const addcomments = document.querySelector(".addcomments");
  const addcomment = document.querySelector(".addcomment");
  const inputtext = document.querySelector(".inputtext");
  const inputbox2 = document.querySelector(".inputbox2");
  editpost.style.display = "none";
  bgcolor.style.backgroundColor = "";
  inputtext.style.backgroundColor = "";
  inputbox2.style.backgroundColor = "";
  likecontainer2.style.backgroundColor = "";
  postedsection.style.backgroundColor = "";
  addcomments.style.backgroundColor = "";
  addcomment.style.backgroundColor = "";
};
const changedata = () => {
  const Enable = document.querySelector("#Enable");
  const posteddata1 = document.querySelector(".posteddata1");
  const postedsection = document.querySelector(".postedsection");
  const imagesection = document.querySelector(".imagesection");
  const imagesection1 = document.querySelector(".imagesection1");
  const addcomments = document.querySelector(".addcomments");
  const likecontainer = document.querySelector(".likecontainer");
  posteddata1.innerText = Enable.value.trim();
  if (imagesection.innerHTML != "") {
    imagesection1.innerHTML += imagesection.innerHTML;
    postedsection.style.height = "20rem";
    addcomments.style.top = "15rem";
    likecontainer.style.top = "11rem";
  }
  hidenow();
};
const bold = () => {
  const Enable = document.querySelector("#Enable");
  Enable.addEventListener("focus", () => {
    Enable.style.fontWeight = "bold";
  });
};
const italic = () => {
  const Enable = document.querySelector("#Enable");
  Enable.addEventListener("focus", () => {
    Enable.style.fontStyle = "italic";
  });
};
document.addEventListener("DOMContentLoaded", () => {
  const invertedcomma = () => {
    const Enable = document.querySelector("#Enable");
    if (Enable) {
      Enable.value += `""`;
    }
  };

  document
    .querySelector(".invertedcommassvg")
    .addEventListener("click", invertedcomma);
});

document.addEventListener("DOMContentLoaded", () => {
  const attherate = () => {
    const Enable = document.querySelector("#Enable");

    if (Enable) {
      Enable.value = Enable.value.trim(); // Remove extra spaces
      Enable.value += "@";

      // Delay and remove {} if they appear
      setTimeout(() => {
        Enable.value = Enable.value.replace(/\{\}/g, "");
      }, 1);
    }
  };

  document.querySelector(".attheratesvg").addEventListener("click", attherate);
});

document.addEventListener("DOMContentLoaded", () => {
  const curlybraces = () => {
    const Enable = document.querySelector("#Enable");

    if (Enable) {
      Enable.value = Enable.value.trim();
      Enable.value += "{}";
    }
  };

  document
    .querySelector(".curlybracessvg")
    .addEventListener("click", curlybraces);
});

const inputimg = () => {
  const fileInput = document.querySelector("#fileInput");
  const imagesection = document.querySelector(".imagesection");

  fileInput.click();

  fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0]; // Get the selected file

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e) {
        const img = document.createElement("img");
        img.src = e.target.result; // Base64 image URL
        img.style.maxWidth = "20%"; // Ensure the image fits
        document.querySelector(".imagesection").appendChild(img); // Insert image
        imagesection.style.display = "block";
      };
      reader.readAsDataURL(file); // Convert image to Base64
    }
    fileInput.value = "";
  });
};

const closetryquora=()=>{
  const tryquorasection=document.querySelector(".tryquorasection");
  const maincontainer = document.querySelector(".main_container");
  const styleeffect = document.querySelector(".styleeffect");
  const askquestions = document.querySelector(".ask_questions");
  const postsection1 = document.querySelector(".postsection1");
  const postsection2 = document.querySelector(".postsection2");
  const postsection3 = document.querySelector(".postsection3");
  const postsection4 = document.querySelector(".postsection4");
  const Nav = document.querySelector("#Nav");
  styleeffect.style.backgroundColor = "";
  askquestions.style.position = "sticky";
  postsection1.style.filter = "";
  postsection2.style.filter = "";
  postsection3.style.filter = "";
  postsection4.style.filter = "";
  askquestions.style.filter = "";
  Nav.style.filter = "";
  maincontainer.style.filter = "";
  tryquorasection.style.display="none";
}
const monthlypriceshow=()=>{
  const pricedetails=document.querySelector(".pricedetails");
  const tryquora6=document.querySelector(".tryquora6");
  const tryquora7=document.querySelector(".tryquora7");
  const yearlytxt=document.querySelector(".yearlytxt");
  const pricediv1=document.querySelector(".pricediv1");
  pricedetails.innerText="$6.99/mo";
  tryquora6.style.border="1px solid gainsboro";
  tryquora6.style.backgroundColor="white";
  yearlytxt.style.color="black";
  pricediv1.style.color="black";
  tryquora7.style.border="1px solid rgb(46, 105, 255)";
  tryquora7.style.backgroundColor="rgb(247,247,247)";
}
const yearlypriceshow=()=>{
  const pricedetails=document.querySelector(".pricedetails");
  const tryquora6=document.querySelector(".tryquora6");
  const tryquora7=document.querySelector(".tryquora7");
  const yearlytxt=document.querySelector(".yearlytxt");
  const pricediv1=document.querySelector(".pricediv1");
  const monthlytxt=document.querySelector(".monthlytxt");
  const pricediv2=document.querySelector(".pricediv2");

  pricedetails.innerText="$47.88/yr";
  tryquora7.style.border="1px solid gainsboro";
  tryquora7.style.backgroundColor="white";
  yearlytxt.style.color="rgb(46, 105, 255)";
  pricediv1.style.color="rgb(46, 105, 255)";
  tryquora6.style.border="1px solid rgb(46, 105, 255)";
  tryquora6.style.backgroundColor="rgb(247,247,247)"; 
  monthlytxt.style.color="black";
  pricediv2.style.color="black";
}