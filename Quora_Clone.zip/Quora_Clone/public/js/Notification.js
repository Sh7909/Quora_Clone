const home = () => {
  localStorage.setItem("runhomefunction", "true");
};
const followingicon = () => {
  const homeicon = document.querySelector("#homeicon");
  const Homeiconline = document.querySelector(".Homeiconline");
  const following = document.querySelector(".following");
  const answer = document.querySelector(".answer");
  const notifications = document.querySelector(".notifications");
  const followingicon = document.querySelectorAll(".followingicon");
  const answericon = document.querySelectorAll(".answericon");
  const notificationicon = document.querySelectorAll(".notificationicon");
  followingicon.forEach((icon) => {
    icon.setAttribute("fill", "rgb(169, 44, 40)");
  });
  following.style.border = "2px solid rgb(169, 44, 40)";
  homeicon.setAttribute("fill", "#666666");
  answericon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  notificationicon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  following.style.display = "block";
  Homeiconline.style.display = "none";
  answer.style.display = "none";
  notifications.style.display = "none";
};
const answericon = () => {
  localStorage.setItem("runAnswerFunction", "true");
};
const notificationicon = (event) => {
  event.preventDefault();
  const homeicon = document.querySelector("#homeicon");
  const Homeiconline = document.querySelector(".Homeiconline");
  const following = document.querySelector(".following");
  const answer = document.querySelector(".answer");
  const notifications = document.querySelector(".notifications");
  const followingicon = document.querySelectorAll(".followingicon");
  const answericon = document.querySelectorAll(".answericon");
  const notificationicon = document.querySelectorAll(".notificationicon");
  notificationicon.forEach((icon) => {
    icon.setAttribute("fill", "rgb(169, 44, 40)");
  });
  notifications.style.border = "2px solid rgb(169, 44, 40)";
  homeicon.setAttribute("fill", "#666666");
  followingicon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  answericon.forEach((icon) => {
    icon.setAttribute("fill", "#666666");
  });
  following.style.display = "none";
  Homeiconline.style.display = "none";
  answer.style.display = "none";
  notifications.style.display = "block";
};
// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
  const tooltip = document.createElement("div");
  tooltip.className = "tooltip";
  document.body.appendChild(tooltip);
})


// Show tooltip
const tooltip = document.createElement("div");
function showTooltip(event) {
  const text = event.target.getAttribute("data-tooltip");
  if (text) {
    tooltip.textContent = text;
    tooltip.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip.style.top = `${event.pageY + tooltipOffset}px`;
}

// Hide tooltip
function hideTooltip() {
  tooltip.classList.remove("show");
}
// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip2 = document.createElement("div");
tooltip2.className = "tooltiptwo";
document.body.appendChild(tooltip2);
})

// Show tooltip
const tooltip2 = document.createElement("div");
function showTooltip2(event) {
  const text2 = event.target.getAttribute("data-tooltip");
  if (text2) {
    tooltip2.textContent = text2;
    tooltip2.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip2(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip2.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip2.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip2() {
  tooltip2.classList.remove("show");
}
// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip3 = document.createElement("div");
tooltip3.className = "tooltipthree";
document.body.appendChild(tooltip3);
});

// Show tooltip
const tooltip3 = document.createElement("div");
function showTooltip3(event) {
  const text3 = event.target.getAttribute("data-tooltip");
  if (text3) {
    tooltip3.textContent = text3;
    tooltip3.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip3(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip3.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip3.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip3() {
  tooltip3.classList.remove("show");
}
//Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip4 = document.createElement("div");
tooltip4.className = "tooltipfour";
document.body.appendChild(tooltip4);
});

// Show tooltip
const tooltip4 = document.createElement("div");
function showTooltip4(event) {
  const text4 = event.target.getAttribute("data-tooltip");
  if (text4) {
    tooltip4.textContent = text4;
    tooltip4.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip4(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip4.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip4.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip4() {
  tooltip4.classList.remove("show");
}

// Create a tooltip element
document.addEventListener('DOMContentLoaded',()=>{
const tooltip5 = document.createElement("div");
tooltip5.className = "tooltipfive";
document.body.appendChild(tooltip5);
})

// Show tooltip
const tooltip5 = document.createElement("div");
function showTooltip5(event) {
  const text5 = event.target.getAttribute("data-tooltip");
  if (text5) {
    tooltip5.textContent = text5;
    tooltip5.classList.add("show");
  }
}

// Move tooltip along with the cursor
function moveTooltip5(event) {
  const tooltipOffset = 10; // Offset from cursor
  tooltip5.style.left = `${event.pageX + tooltipOffset}px`;
  tooltip5.style.top = `${event.pageY + tooltipOffset}px`;
}

//Hide tooltip
function hideTooltip5() {
  tooltip5.classList.remove("show");
}

function tryquora(){
  const tryquorasection = document.querySelector(".tryquorasection");
  const notificationdiv=document.querySelector('.notificationdiv');
  const notification1=document.querySelector('.notification1');
  const notification2=document.querySelector('.notification2');
  const notification3=document.querySelector('.notification3');
  const notification4=document.querySelector('.notification4');
  const notification5=document.querySelector('.notification5');
  const Nav = document.querySelector("#Nav");
  tryquorasection.style.display = "block";
  notificationdiv.style.backgroundColor="rgb(128, 128, 128)";
  notification1.style.backgroundColor="rgb(128, 128, 128)";
  notification2.style.backgroundColor="rgb(128, 128, 128)";
  notification3.style.backgroundColor="rgb(128, 128, 128)";
  notification4.style.backgroundColor="rgb(128, 128, 128)";
  notification5.style.backgroundColor="rgb(128, 128, 128)";
  Nav.style.filter = "brightness(0.5)";
};
const closetryquora=()=>{
  const tryquorasection = document.querySelector(".tryquorasection");
  const notificationdiv=document.querySelector('.notificationdiv');
  const notification1=document.querySelector('.notification1');
  const notification2=document.querySelector('.notification2');
  const notification3=document.querySelector('.notification3');
  const notification4=document.querySelector('.notification4');
  const notification5=document.querySelector('.notification5');
  const Nav=document.querySelector('#Nav');
  tryquorasection.style.display = "none";
  notificationdiv.style.backgroundColor="";
  notification1.style.backgroundColor="";
  notification2.style.backgroundColor="";
  notification3.style.backgroundColor="";
  notification4.style.backgroundColor="";
  notification5.style.backgroundColor="";
  Nav.style.filter = "";

}
const first = () => {
  const opendialogbox1 = document.querySelector(".opendialogbox1");
  const currentDisplay = window.getComputedStyle(opendialogbox1).display;
  if (currentDisplay == "none") {
    opendialogbox1.style.display = "block";
  } else {
    opendialogbox1.style.display = "none";
  }
};
const second = () => {
  const opendialogbox2 = document.querySelector(".opendialogbox2");
  const currentDisplay = window.getComputedStyle(opendialogbox2).display;
  if (currentDisplay == "none") {
    opendialogbox2.style.display = "block";
  } else {
    opendialogbox2.style.display = "none";
  }
};
const Third = () => {
  const opendialogbox3 = document.querySelector(".opendialogbox3");
  const currentDisplay = window.getComputedStyle(opendialogbox3).display;
  if (currentDisplay == "none") {
    opendialogbox3.style.display = "block";
  } else {
    opendialogbox3.style.display = "none";
  }
};
const Four = () => {
  const opendialogbox4 = document.querySelector(".opendialogbox4");
  const currentDisplay = window.getComputedStyle(opendialogbox4).display;
  if (currentDisplay == "none") {
    opendialogbox4.style.display = "block";
  } else {
    opendialogbox4.style.display = "none";
  }
};
const Fifth = () => {
  const opendialogbox5 = document.querySelector(".opendialogbox5");
  const currentDisplay = window.getComputedStyle(opendialogbox5).display;
  if (currentDisplay == "none") {
    opendialogbox5.style.display = "block";
  } else {
    opendialogbox5.style.display = "none";
  }
};
const start1 = () => {
  document.querySelector(".opendialogbox1").style.display = "none";
  document.querySelector(".notification1").style.backgroundColor = "white";
};
const start2 = () => {
  document.querySelector(".opendialogbox2").style.display = "none";
  document.querySelector(".notification2").style.backgroundColor = "white";
};
const start3 = () => {
  document.querySelector(".opendialogbox3").style.display = "none";
  document.querySelector(".notification3").style.backgroundColor = "white";
};
const start4 = () => {
  document.querySelector(".opendialogbox4").style.display = "none";
  document.querySelector(".notification4").style.backgroundColor = "white";
};
const start5 = () => {
  document.querySelector(".opendialogbox5").style.display = "none";
  document.querySelector(".notification5").style.backgroundColor = "white";
};
const fun1 = () => {
  let element1 = document.querySelector("#all_notifications");
  let element2 = document.querySelector("#stories");
  let element3 = document.querySelector("#questions");
  let element4 = document.querySelector("#yourprofile");
  let element5 = document.querySelector("#yourcontent");
  const notification = document.querySelector(".notification");
  const div1=document.querySelector('.div1');
  element1.style.color = "rgb(242, 41, 53)";
  element2.style.color = "black";
  element3.style.color = "black";
  element4.style.color = "black";
  element5.style.color = "black";
  notification.style.display = "block";
  div1.style.display="none";

};
const fun2 = () => {
  let element1 = document.querySelector("#all_notifications");
  let element2 = document.querySelector("#stories");
  let element3 = document.querySelector("#questions");
  let element4 = document.querySelector("#yourprofile");
  let element5 = document.querySelector("#yourcontent");
  const text1 = document.querySelector("#text1");
  const notification = document.querySelector(".notification");
  const div1=document.querySelector('.div1');
  element1.style.color = "black";
  element2.style.color = "rgb(242, 41, 53)";
  element3.style.color = "black";
  element4.style.color = "black";
  element5.style.color = "black";
  text1.innerText = "Stories";
  notification.style.display = "none";
  div1.style.display="block";
};
const fun3 = () => {
  let element1 = document.querySelector("#all_notifications");
  let element2 = document.querySelector("#stories");
  let element3 = document.querySelector("#questions");
  let element4 = document.querySelector("#yourprofile");
  let element5 = document.querySelector("#yourcontent");
  const text1 = document.querySelector("#text1");
  const notification = document.querySelector(".notification");
  const div1=document.querySelector('.div1');

  element1.style.color = "black";
  element2.style.color = "black";
  element3.style.color = "rgb(242, 41, 53)";
  element4.style.color = "black";
  element5.style.color = "black";
  text1.innerText = "Questions";
  notification.style.display = "none";
  div1.style.display="block";
};
const fun4 = () => {
  let element1 = document.querySelector("#all_notifications");
  let element2 = document.querySelector("#stories");
  let element3 = document.querySelector("#questions");
  let element4 = document.querySelector("#yourprofile");
  let element5 = document.querySelector("#yourcontent");
  const text1 = document.querySelector("#text1");
  const notification = document.querySelector(".notification");
  const div1=document.querySelector('.div1');

  element1.style.color = "black";
  element2.style.color = "black";
  element3.style.color = "black";
  element4.style.color = "rgb(242, 41, 53)";
  element5.style.color = "black";
  text1.innerText = "Your profile";
  notification.style.display = "none";
  div1.style.display="block";
};
const fun5 = () => {
  let element1 = document.querySelector("#all_notifications");
  let element2 = document.querySelector("#stories");
  let element3 = document.querySelector("#questions");
  let element4 = document.querySelector("#yourprofile");
  let element5 = document.querySelector("#yourcontent");
  const text1 = document.querySelector("#text1");
  const notification = document.querySelector(".notification");
  const div1=document.querySelector('.div1');

  element1.style.color = "black";
  element2.style.color = "black";
  element3.style.color = "black";
  element4.style.color = "black";
  element5.style.color = "rgb(242, 41, 53)";
  text1.innerText = "Your content";
  notification.style.display = "none";
  div1.style.display="block";
};
const Openlangdivcontainer=()=>{
  const languagediv=document.querySelector('.languagediv');
  const currentDisplay=window.getComputedStyle(languagediv).display;
  if(currentDisplay=="none"){
    languagediv.style.display="block";
  }
  else{
    languagediv.style.display="none";
  }
}
const closelangdiv=()=>{
  const languagediv=document.querySelector('.languagediv');
  languagediv.style.display="none";
}
const createpost = () => {
  const postdiv = document.querySelector("#postdiv");
  const Enable = document.querySelector("#Enable");
  postdiv.style.display = "none";
  Enable.style.display = "block";
};
const exec2 = () => {
  const textarea = document.querySelector("#Enable");
  const postbtn = document.querySelector("#postbtn");

  if (textarea.value.trim() === "") {
    postbtn.style.opacity = 0.4;
    postbtn.style.cursor = "default";
  } else {
    postbtn.style.opacity = 1;
    postbtn.style.cursor = "pointer";
  }
};
const showstyles = () => {
  const shownow = document.querySelector(".shownow");
  const photosvg = document.querySelector("#photosvg");
  const fontstylessvg = document.querySelector("#fontstylessvg");
  shownow.style.display = "block";
  shownow.style.display = "flex";
  photosvg.style.display = "none";
  fontstylessvg.style.display = "none";
};
const togglefnc = () => {
  const dropdowntogglebtn = document.querySelector(".dropdowntogglebtn");
  const shownow = document.querySelector(".shownow");
  const photosvg = document.querySelector("#photosvg");
  const fontstylessvg = document.querySelector("#fontstylessvg");
  if (dropdowntogglebtn.style.display == "none") {
    shownow.style.display = "block";
    photosvg.style.display = "none";
    fontstylessvg.style.display = "none";
  } else {
    shownow.style.display = "none";
    photosvg.style.display = "block";
    fontstylessvg.style.display = "block";
  }
};
const showmenudata=()=>{
  const droplist=document.querySelector('#droplist');
  const currentDisplay=window.getComputedStyle(droplist).display;
  if(currentDisplay=="none"){
    droplist.style.display="block";
  }
  else{
    droplist.style.display="none";
  }
}
const menu1 = () => {
  const img1 = document.querySelector("#img1");
  const img2 = document.querySelector("#img2");
  const change = document.querySelector("#change");
  const menu1 = document.querySelector(".menu1");
  img1.style.display = "block";
  img2.style.display = "none";
  change.innerText = menu1.innerText;
};
const menu2 = () => {
  const img1 = document.querySelector("#img1");
  const img2 = document.querySelector("#img2");
  const menu2 = document.querySelector(".menu2");
  const change = document.querySelector("#change");
  img1.style.display = "none";
  img2.style.display = "block";
  change.innerText = menu2.innerText;
};
const inputimg = () => {
  const fileInput = document.querySelector("#fileInput");
  const imagesection = document.querySelector(".imagesection");

  fileInput.click();

  fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0]; // Get the selected file

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e) {
        const img = document.createElement("img");
        img.src = e.target.result; // Base64 image URL
        img.style.maxWidth = "20%"; // Ensure the image fits
        document.querySelector(".imagesection").appendChild(img); // Insert image
        imagesection.style.display = "block";
      };
      reader.readAsDataURL(file); // Convert image to Base64
    }
    fileInput.value = "";
  });
};

  const invertedcomma = () => {
    const Enable = document.querySelector("#Enable");
    if (Enable) {
      Enable.value += `""`;
    }
  };
  const attherate = () => {
    const Enable = document.querySelector("#Enable");

    if (Enable) {
      Enable.value = Enable.value.trim(); // Remove extra spaces
      Enable.value += "@";

      // Delay and remove {} if they appear
      setTimeout(() => {
        Enable.value = Enable.value.replace(/\{\}/g, "");
      }, 1);
    }
  };


  const curlybraces = () => {
    const Enable = document.querySelector("#Enable");

    if (Enable) {
      Enable.value = Enable.value.trim();
      Enable.value += "{}";
    }
  };

const senddata = () => {
  const getdata = document.querySelector("#Enable").value;
  const imageElements = document.querySelectorAll(".imagesection img");

  const formData = new FormData();
  formData.append("getdata", getdata);

  let imagePromises = [];

  imageElements.forEach((imageElement, index) => {
    imagePromises.push(
      fetch(imageElement.src)
        .then((response) => response.blob())
        .then((blob) => {
          const file = new File([blob], `uploaded_image_${index}.jpg`, {
            type: blob.type,
          });
          formData.append("images", file);
        })
    );
  });

  Promise.all(imagePromises)
    .then(() => {
      return fetch("/postdata", {
        method: "POST",
        body: formData,
      });
    })
    .then((response) => {
      if (response.redirected) {
        window.location.href = response.url;
      }
    })
    .catch((err) => console.error("Error:", err));
};
const opendialog = () => {
  const questiondialogbox = document.querySelector(".questiondialogbox");
  const notificationdiv=document.querySelector('.notificationdiv');
  const notification1=document.querySelector('.notification1');
  const notification2=document.querySelector('.notification2');
  const notification3=document.querySelector('.notification3');
  const notification4=document.querySelector('.notification4');
  const notification5=document.querySelector('.notification5');

  const Nav = document.querySelector("#Nav");
  questiondialogbox.style.display = "block";
  Nav.style.filter = "brightness(0.5)";
  notificationdiv.style.backgroundColor="rgb(128, 128, 128)";
  notification1.style.backgroundColor="rgb(128, 128, 128)";
  notification2.style.backgroundColor="rgb(128, 128, 128)";
  notification3.style.backgroundColor="rgb(128, 128, 128)";
  notification4.style.backgroundColor="rgb(128, 128, 128)";
  notification5.style.backgroundColor="rgb(128, 128, 128)";
};
const startnow = () => {
  const questionstart = document.querySelector("#questionstart");
  const after = document.querySelector("#after");
  questionstart.style.display = "none";
  after.style.display = "block";
};
const hovercolor = () => {
  const line = document.querySelector(".line");
  line.style.border = "1px solid blue";
};
const hoveroutcolor = () => {
  const line = document.querySelector(".line");
  line.style.border = "";
};
const exec = () => {
  const textarea = document.querySelector("#after");
  const line = document.querySelector(".line");
  const addquestion = document.querySelector("#addquestion");

  // Get the scroll height (amount of overflow) of the textarea
  const textHeight = textarea.scrollHeight;

  // Adjust the position of the <hr> based on the textarea's height
  // Add some spacing

  if (textarea.value.trim() === "") {
    addquestion.style.opacity = 0.4;
    line.style.top = "10%";
  } else {
    addquestion.style.cursor="pointer";
    addquestion.style.opacity = 1;
    line.style.top = `${textHeight + 0.2}px`;
  }
};
const questionbox = () => {
  const createpost = document.querySelector(".createpost");
  const line2 = document.querySelector(".line2");
  const box6 = document.querySelector(".box6");
  const box9 = document.querySelector(".box9");
  const box10 = document.querySelector(".box10");
  const box11 = document.querySelector(".box11");
  const text3 = document.querySelector(".text3");
  const box12 = document.querySelector(".box12");
  const startquestion = document.querySelector(".startquestion");
  const Boxtwo = document.querySelector(".Boxtwo");
  const boxtwo = document.querySelector(".boxtwo");
  createpost.style.display = "none";
  box9.style.opacity = 1;
  box10.style.opacity = 0;
  line2.style.display = "none";
  box11.style.display = "block";
  box12.style.display = "block";
  box12.style.display = "flex";
  text3.style.display = "none";
  Boxtwo.style.display = "none";
  boxtwo.style.display = "block";
  boxtwo.style.display = "flex";
  startquestion.style.display = "block";
  box6.onmouseover = () => {
    box6.style.backgroundColor = "white";
  };
  box6.onmouseout = () => {
    box6.style.backgroundColor = "white";
  };
};
const postdiv = () => {
  const line2 = document.querySelector(".line2");
  const box6 = document.querySelector(".box6");
  const box7 = document.querySelector(".box7");
  const box9 = document.querySelector(".box9");
  const box10 = document.querySelector(".box10");
  const box12 = document.querySelector(".box12");
  const createpost = document.querySelector(".createpost");
  const text3 = document.querySelector(".text3");
  const boxtwo = document.querySelector(".boxtwo");
  const Boxtwo = document.querySelector(".Boxtwo");
  const staticimg = document.querySelector(".staticimg");
  const startquestion = document.querySelector(".startquestion");
  createpost.style.display = "block";
  line2.style.display = "block";
  Boxtwo.style.display = "block";
  Boxtwo.style.display = "flex";
  boxtwo.style.display = "none";
  box9.style.opacity = 0;
  box10.style.opacity = 1;
  box12.style.display = "none";
  staticimg.style.display = "block";
  startquestion.style.display = "none";
  text3.style.display = "block";
  text3.style.display = "flex";
  box6.onmouseover = () => {
    box6.style.backgroundColor = "rgb(247, 247, 247)";
  };
  box6.onmouseout = () => {
    box6.style.backgroundColor = "";
  };
  box7.onmouseover = () => {
    box7.style.backgroundColor = "white";
  };
  box7.onmouseout = () => {
    box7.style.backgroundColor = "white";
  };
};
const bold = () => {
  const Enable = document.querySelector("#Enable");
  Enable.addEventListener("focus", () => {
    Enable.style.fontWeight = "bold";
  });
};
const italic = () => {
  const Enable = document.querySelector("#Enable");
  Enable.addEventListener("focus", () => {
    Enable.style.fontStyle = "italic";
  });
};
const close1=()=>{
  const questiondialogbox=document.querySelector(".questiondialogbox");
  const notificationdiv=document.querySelector('.notificationdiv');
  const notification1=document.querySelector('.notification1');
  const notification2=document.querySelector('.notification2');
  const notification3=document.querySelector('.notification3');
  const notification4=document.querySelector('.notification4');
  const notification5=document.querySelector('.notification5');
  const Nav = document.querySelector("#Nav");
  questiondialogbox.style.display="none";
  Nav.style.filter = "";
  notificationdiv.style.backgroundColor="";
  notification1.style.backgroundColor="";
  notification2.style.backgroundColor="";
  notification3.style.backgroundColor="";
  notification4.style.backgroundColor="";
  notification5.style.backgroundColor="";
}
const monthlypriceshow=()=>{
  const pricedetails=document.querySelector(".pricedetails");
  const tryquora6=document.querySelector(".tryquora6");
  const tryquora7=document.querySelector(".tryquora7");
  const yearlytxt=document.querySelector(".yearlytxt");
  const pricediv1=document.querySelector(".pricediv1");
  pricedetails.innerText="$6.99/mo";
  tryquora6.style.border="1px solid gainsboro";
  tryquora6.style.backgroundColor="white";
  yearlytxt.style.color="black";
  pricediv1.style.color="black";
  tryquora7.style.border="1px solid rgb(46, 105, 255)";
  tryquora7.style.backgroundColor="rgb(247,247,247)";
}
const yearlypriceshow=()=>{
  const pricedetails=document.querySelector(".pricedetails");
  const tryquora6=document.querySelector(".tryquora6");
  const tryquora7=document.querySelector(".tryquora7");
  const yearlytxt=document.querySelector(".yearlytxt");
  const pricediv1=document.querySelector(".pricediv1");
  const monthlytxt=document.querySelector(".monthlytxt");
  const pricediv2=document.querySelector(".pricediv2");

  pricedetails.innerText="$47.88/yr";
  tryquora7.style.border="1px solid gainsboro";
  tryquora7.style.backgroundColor="white";
  yearlytxt.style.color="rgb(46, 105, 255)";
  pricediv1.style.color="rgb(46, 105, 255)";
  tryquora6.style.border="1px solid rgb(46, 105, 255)";
  tryquora6.style.backgroundColor="rgb(247,247,247)"; 
  monthlytxt.style.color="black";
  pricediv2.style.color="black";
}