const emailinput = () => {
  const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const emailerror = document.querySelector(".emailerror");
  const emailinput = document.querySelector(".emailinput").value;
  if (regex.test(emailinput)) {
    emailerror.style.display = "none";
  } else {
    emailerror.style.display = "block";
    emailerror.innerText = "Please enter valid email address";
  }
};
const passwordinput1 = () => {
  const regex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  const passworderror = document.querySelector(".passworderror");
  const passwordinput = document.querySelector(".passwordinput").value;
  if (regex.test(passwordinput)) {
    passworderror.style.display = "none";
  } else {
    passworderror.style.display = "block";
    passworderror.innerText = "Please enter valid password";
  }
};
const checklogin = () => {
  const emailinput = document.querySelector(".emailinput");
  const passwordinput = document.querySelector(".passwordinput");
  const emailerror = document.querySelector(".emailerror").style.display;
  const passworderror = document.querySelector(".passworderror").style.display;

  if (
    emailinput.value == "" ||
    passwordinput.value == "" ||
    emailerror == "block" ||
    passworderror == "block"
  ) {
    alert("Please Fill all details");
  } else {
    const inputstring=emailinput.value;
    const value1=inputstring.trim().charAt(0);
    window.location.href = `/home?value1=${encodeURIComponent(value1)}`;
  }
};
const signup = () => {
  const Formcontainer1 = document.querySelector(".Form_container1");
  const Formcontainer2 = document.querySelector(".Form_container2");
  const LoginSignupContainer = document.querySelector(".LoginSignupContainer");
  const container1 = document.querySelector("#container1");
  const headingtext=document.querySelector('.headingtext');
  const Signupbtn=document.querySelector('.Signupbtn');
  const Loginbtn2=document.querySelector('.Loginbtn2');
  Formcontainer1.style.display = "none";
  Formcontainer2.style.display = "block";
  LoginSignupContainer.style.height = "40rem";
  container1.style.position = "relative";
  container1.style.top = "2rem";
  headingtext.style.top="20%";
  Signupbtn.style.top="26rem";
  Loginbtn2.style.top="93%";
};
const passwordinput2 = () => {
  const regex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  const passworderror1 = document.querySelector(".passworderror1");
  const passwordinput1 = document.querySelector(".passwordinput1").value;

  if (regex.test(passwordinput1)) {
    passworderror1.style.display = "none";
  } else {
    passworderror1.style.display = "block";
    passworderror1.innerText = "Please enter valid password";
  }
};
const passwordinput3 = () => {
  const regex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  const passworderror2 = document.querySelector(".passworderror2");
  const passwordinput2 = document.querySelector(".passwordinput2").value;

  if (regex.test(passwordinput2)) {
    passworderror2.style.display = "none";
  } else {
    passworderror2.style.display = "block";
    passworderror2.innerText = "Please enter valid Confirm password";
  }
};
const signup1 = () => {
  const firstname = document.querySelector(".first_name").value;
  const lastname = document.querySelector(".last_name").value;
  const passwordinput1 = document.querySelector(".passwordinput1").value;
  const passwordinput2 = document.querySelector(".passwordinput2").value;
  const passworderror1 =
    document.querySelector(".passworderror1").style.display;
  const passworderror2 =
    document.querySelector(".passworderror2").style.display;

  if (
    firstname == "" ||
    lastname == "" ||
    passwordinput1 == "" ||
    passwordinput2 == "" ||
    passworderror1 == "block" ||
    passworderror2 == "block"
  ) {
    alert("Please enter Correct Details");
  } else {
    window.location.href = "/home";
  }
};
const OpenloginForm=()=>{
 const Formcontainer1=document.querySelector('.Form_container1');
 const Formcontainer2=document.querySelector('.Form_container2');
 const LoginSignupContainer=document.querySelector('.LoginSignupContainer');
 const headingtext=document.querySelector('.headingtext');
 Formcontainer1.style.display="block";
 Formcontainer2.style.display="none";
 LoginSignupContainer.style.height="28rem";
 headingtext.style.top="23%";
}