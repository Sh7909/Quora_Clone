const express = require("express");
const multer = require("multer");
const path = require("path");

const app = express();
app.use(express.json()); // For parsing application/json
app.use(express.urlencoded({ extended: true })); // For parsing application/x-www-form-urlencoded

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });

app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.get("/", (req, res) => {
  res.render("LoginSignup");
});
app.get('/logout',(req,res)=>{
  res.redirect('/');
})
app.get("/home", (req, res) => {
  const data=req.query.value1;
  res.render("index",{
    loginname:data,
  });
});
app.get("/answer", (req, res) => {
  res.render("answer");
});
app.get('/notifications',(req,res)=>{
  res.render("Notifications");
});
app.post("/spacecreatedpage", (req, res) => {
  try {
    const inputdata = req.body.inputdata;
    res.json({
      redirectUrl: `/nextpage?data=${encodeURIComponent(inputdata)}`,
    });
  } catch (err) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get("/nextpage", (req, res) => {
  const getinputdata = req.query.data;
  res.render("space", { data: getinputdata });
});

app.post("/postdata", upload.array("images", 10), (req, res) => {
  // Accept up to 10 images
  const getdata = req.body.getdata;

  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: "No images uploaded" });
  }

  const imageFiles = req.files.map((file) => `/uploads/${file.filename}`); // Store all image paths

  // Redirect with multiple images
  res.redirect(
    `/posted?getdata=${encodeURIComponent(
      getdata
    )}&imageFiles=${encodeURIComponent(JSON.stringify(imageFiles))}`
  );
});
app.get("/posted", (req, res) => {
  const { getdata, imageFiles } = req.query;

  // Parse imageFiles if it exists
  const parsedImageFiles = imageFiles
    ? JSON.parse(decodeURIComponent(imageFiles))
    : [];

  res.render("posted", {
    getdata,
    imageFiles: parsedImageFiles, // Pass an array
  });
});

app.post("/postanswers", upload.array("images", 10), (req, res) => {
  const getdata = req.body.getdata || "";
  const showquestions = req.body.showquestions || "";

  if (!showquestions) {
    return res.status(400).json({ error: "Question is missing!" });
  }

  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: "No images uploaded" });
  }

  const imageFiles = req.files.map((file) => `/uploads/${file.filename}`);

  res.redirect(
    `/postedpage?getdata=${encodeURIComponent(
      getdata
    )}&showquestions=${encodeURIComponent(
      showquestions
    )}&imageFiles=${encodeURIComponent(JSON.stringify(imageFiles))}`
  );
});

app.get("/postedpage", (req, res) => {
  const { getdata, showquestions, imageFiles } = req.query;

  const parsedImageFiles = imageFiles
    ? JSON.parse(decodeURIComponent(imageFiles))
    : [];

  res.render("postedanswers", {
    getdata,
    showquestions, // Make sure it's being sent
    imageFiles: parsedImageFiles,
  });
});

module.exports = app;
